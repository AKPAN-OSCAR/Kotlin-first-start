# SABI Android Path

A self-paced, project-based path from zero to a published Android app, built with **Kotlin** and **Jetpack Compose**. It is structured like The Odin Project: read a lesson, do the practice, build the project, push to GitHub, move on.

## How the repo is organised

```
sabi-android-path/
├── curriculum/     <- READ HERE FIRST. Lessons, in order.
│   ├── 00-start-here/
│   ├── 01-kotlin-foundations/
│   ├── 02-android-foundations/
│   ├── 03-compose-ui/
│   ├── 04-architecture/
│   ├── 05-data-and-networking/
│   ├── 06-auth-and-backend/
│   ├── 07-quality-and-shipping/
│   ├── 08-capstone/
│   └── 09-resources/
└── projects/       <- THEN BUILD HERE. Every lesson points to a project.
    ├── kotlin-exercises/   (runnable Kotlin files, TODOs + solutions)
    └── android/            (Compose app source for each stage)
```

**The loop for every lesson**
1. Read the lesson in `curriculum/`.
2. Type the examples yourself (do not copy-paste).
3. Open the matching folder in `projects/`, do the exercise or build the app.
4. Commit and push. One lesson, one commit.
5. Answer the knowledge-check questions out loud or in a notes file. If you can't, re-read.

## The path at a glance

| Stage | Lessons | Project you build |
|---|---|---|
| 0. Start here | how to learn, environment setup | Hello World app on your device |
| 1. Kotlin | variables, control flow, null safety, classes, collections, lambdas | `projects/kotlin-exercises` |
| 2. Android foundations | project structure, Gradle, lifecycle, resources | Run and explore a blank project |
| 3. Compose UI | layouts, theming, state, lists, forms, navigation | Business card, tip calculator, affirmations list, **SABI auth screens** |
| 4. Architecture | ViewModel, coroutines, Flow, repository, Hilt | Sign-up ViewModel with tests |
| 5. Data | Room, DataStore, Retrofit | Notes app |
| 6. Auth | Firebase Auth, validation, security | Real sign-up/sign-in |
| 7. Shipping | testing, debugging, release | Signed release build |
| 8. Capstone | put it all together | Your own SABI feature |

## Using the projects

The Android projects are **source-only** (no Gradle wrapper, no generated files) so the repo stays small and you learn how projects are set up. See [`projects/android/SETUP.md`](projects/android/SETUP.md) for how to drop any project into a fresh Android Studio project.

## Version note

Library versions change quickly. This path avoids hard-pinning versions in lessons. When a lesson shows a dependency, use the version Android Studio suggests or the one listed in the official release notes (links are in each lesson). At time of writing: Kotlin 2.4.x, Jetpack Compose 1.12 (stable), Material 3 1.4, Navigation 3 stable.

## Honesty note

The code in this repo was written carefully but **was not compiled by the author in a build environment**. Expect an occasional import or API-version fix. Reading the compiler error and fixing it is part of the training, and the lessons teach you how.

## Contributing / making it yours

Fork it, change the capstone to your own idea, and keep your own notes in `curriculum/` as you learn.
