# State and recomposition

## Introduction
State is any value that can change over time (text typed into a field, a counter, whether a password is visible). In Compose, **UI = f(state)**: when state changes, the affected composables run again.

## Learning outcomes
- Use `remember` and `mutableStateOf`.
- Explain recomposition.
- Hoist state to make composables reusable and testable.
- Survive rotation with `rememberSaveable`.

## Lesson

### State and remember
```kotlin
@Composable
fun Counter() {
    var count by remember { mutableStateOf(0) }
    Button(onClick = { count++ }) { Text("Clicked $count times") }
}
```
- `mutableStateOf` creates observable state. Changing `count` triggers **recomposition** of readers.
- `remember` keeps the value between recompositions. Without it, `count` resets to 0 every time.
- `by` is a Kotlin delegate that lets you read/write `count` directly.

### Recomposition
Compose re-runs only the composables that read the changed state. Don't put slow work or side effects directly in a composable body, because it may run many times.

### rememberSaveable
```kotlin
var name by rememberSaveable { mutableStateOf("") }
```
Survives rotation and process death for simple types. For complex state use a ViewModel (lesson 04).

### State hoisting
Move state **up** and pass down `value` + `onValueChange`.
```kotlin
@Composable
fun NameField(name: String, onNameChange: (String) -> Unit, modifier: Modifier = Modifier) {
    TextField(value = name, onValueChange = onNameChange, modifier = modifier)
}

@Composable
fun Screen() {
    var name by rememberSaveable { mutableStateOf("") }
    NameField(name = name, onNameChange = { name = it })
}
```
`NameField` is **stateless**: easy to preview and test. `Screen` owns the state.

### Unidirectional data flow
State flows **down** (parameters), events flow **up** (callbacks). You'll apply the same idea with ViewModels.

### Derived values
```kotlin
val canSubmit = name.isNotBlank() && password.length >= 6   // just compute it
```
Don't store what you can calculate.

### Common bug
Mutating a regular `MutableList` inside state doesn't trigger updates. Use `mutableStateListOf`, or replace the list with a new one.

## Practice
Build the tip calculator: `projects/android/02-tip-calculator`.

## Knowledge check
- What happens if you remove `remember` from the counter?
- What does state hoisting buy you?
- Why prefer computing `canSubmit` instead of storing it?

## Additional resources
- [State and Jetpack Compose](https://developer.android.com/develop/ui/compose/state)
- [Where to hoist state](https://developer.android.com/develop/ui/compose/state-hoisting)

Previous: [Theming](02-theming-material.md) · Next: [Lists with LazyColumn](04-lists.md)
