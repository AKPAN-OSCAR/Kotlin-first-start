# Forms and the SABI auth screens

## Introduction
Sign-up screens teach text input, keyboard handling, validation and polished styling all at once. In this lesson you read and rebuild the two SABI screens from the design: **Welcome** and **Create Account**.

## Learning outcomes
- Use `TextField` with keyboard options, password masking and a visibility toggle.
- Handle the on-screen keyboard (`imePadding`) and scrolling.
- Break a screen into small composables.
- Draw simple decorative shapes with `Canvas`.

## Lesson

### Anatomy of a text field
```kotlin
var email by rememberSaveable { mutableStateOf("") }
TextField(
    value = email,
    onValueChange = { email = it },
    placeholder = { Text("Enter your email address") },
    singleLine = true,
    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
)
```
`keyboardType` picks the right keyboard. `imeAction` sets the Enter-key behaviour (Next, Done).

### Password fields
```kotlin
var visible by remember { mutableStateOf(false) }
TextField(
    value = password,
    onValueChange = { password = it },
    visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
    trailingIcon = {
        IconButton(onClick = { visible = !visible }) {
            Icon(if (visible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, contentDescription = "Toggle password visibility")
        }
    },
)
```
`VisibilityOff` needs the `material-icons-extended` dependency (or download the vector from Material Symbols).

### Keyboard and scrolling
Wrap the form in `Column(Modifier.verticalScroll(rememberScrollState()).imePadding())`, otherwise the keyboard covers the fields on small phones.

### Reusing a field
In the SABI file, `AuthField(label, icon, value, onValueChange, ...)` is one reusable composable used four times. When you see repeated UI, extract it.

### The "glass" card
A semi-transparent white `background(Color.White.copy(alpha = 0.3f))` plus a thin light border. True blur needs API 31+ (`Modifier.blur`) and affects children too, so a translucent fill is the portable choice.

### Decorations
Circles and rings are drawn with `Canvas { drawCircle(...) }`. Complex 3D art (the cube, donut, pencil) should be exported as images and placed with `Image`.

### Validation (preview)
For now: `canSubmit = name.isNotBlank() && email.contains("@") && password.length >= 6 && password == confirm`. In lessons 04 and 06 you'll move this into a ViewModel and a tested validator.

## Practice
1. Open `projects/android/04-sabi-auth-ui`. Read `AuthScreens.kt` top to bottom and annotate each composable in your notes.
2. Run it with the drawable placeholders listed in that project's README.
3. Challenge: add a **Sign in** screen (email + password only) using the same `AuthField`.

## Knowledge check
- Why is `AuthField` its own composable?
- What does `imePadding()` solve?
- Why are the 3D decorations images instead of Canvas drawings?

## Additional resources
- [TextField in Compose](https://developer.android.com/develop/ui/compose/text/user-input)
- [Keyboard handling and insets](https://developer.android.com/develop/ui/compose/system/insets)
- [Canvas / custom drawing](https://developer.android.com/develop/ui/compose/graphics/draw/overview)

Previous: [Lists](04-lists.md) · Next: [Navigation](06-navigation.md)
