# Composables, layouts and modifiers

## Introduction
Jetpack Compose builds UI by calling Kotlin functions. You describe *what* the screen looks like for the current data, and Compose handles drawing and updating it.

## Learning outcomes
- Write `@Composable` functions and preview them.
- Arrange content with `Column`, `Row` and `Box`.
- Style and size things with `Modifier`.

## Lesson

### A composable
```kotlin
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello, $name!", modifier = modifier)
}

@Preview(showBackground = true)
@Composable
private fun GreetingPreview() {
    Greeting("Ada")
}
```
Rules of thumb: name is a noun starting with a capital letter, it takes data in as parameters, and it takes a `modifier` parameter so callers can adjust it.

### Layout basics
```kotlin
Column(
    modifier = Modifier.fillMaxSize().padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp),
    horizontalAlignment = Alignment.CenterHorizontally
) {
    Text("Title")
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Icon(Icons.Filled.Email, contentDescription = null)
        Text("ada@example.com")
    }
}

Box(contentAlignment = Alignment.Center) {   // children stack on top of each other
    Image(/* background */)
    Text("Overlay")
}
```
- `Column` stacks vertically, `Row` horizontally, `Box` layers.
- `Spacer(Modifier.height(16.dp))` adds empty space.

### Modifiers
Modifiers decorate or change a composable. **Order matters.**
```kotlin
Modifier
    .fillMaxWidth()
    .padding(16.dp)               // outside space (before background)
    .background(Color.Yellow)
    .padding(16.dp)               // inside space (after background)
    .clickable { /* tap */ }
```
Common ones: `size`, `fillMaxWidth`, `weight(1f)` (inside Row/Column), `clip`, `border`, `shadow`, `clickable`, `verticalScroll`.

### Common building blocks
`Text`, `Image`, `Icon`, `Button`, `Card`, `Surface`, `Spacer`, `Scaffold`.

### Units
`dp` for sizes, `sp` for text.

## Practice
Build the business-card app: `projects/android/01-business-card`.

## Knowledge check
- Why does `padding` before `background` look different from after?
- What's the difference between `Column`, `Row` and `Box`?
- Why do composables usually accept a `modifier` parameter?

## Additional resources
- [Compose layout basics](https://developer.android.com/develop/ui/compose/layouts/basics)
- [Compose modifiers](https://developer.android.com/develop/ui/compose/modifiers)
- [Thinking in Compose](https://developer.android.com/develop/ui/compose/mental-model)

Previous: [Activities, lifecycle and resources](../02-android-foundations/02-activity-lifecycle-resources.md) · Next: [Theming and Material 3](02-theming-material.md)
