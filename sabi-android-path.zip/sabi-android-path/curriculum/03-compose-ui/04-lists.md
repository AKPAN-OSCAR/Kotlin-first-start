# Lists with LazyColumn

## Introduction
Most apps are lists: courses, notes, messages. `LazyColumn` only composes the items on screen, so long lists stay fast.

## Learning outcomes
- Show a list with `LazyColumn` and `items`.
- Use stable `key`s.
- Build item layouts with `Card`.
- Add simple item interactions.

## Lesson

### Basic list
```kotlin
data class Course(val id: Int, val title: String, val tutor: String)

@Composable
fun CourseList(courses: List<Course>, modifier: Modifier = Modifier) {
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(courses, key = { it.id }) { course ->
            CourseCard(course)
        }
    }
}

@Composable
fun CourseCard(course: Course, modifier: Modifier = Modifier) {
    Card(modifier = modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(course.title, style = MaterialTheme.typography.titleMedium)
            Text(course.tutor, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
```
**Always give a `key`.** It lets Compose keep the right item state when the list changes.

### LazyRow and grids
`LazyRow` scrolls horizontally. `LazyVerticalGrid(columns = GridCells.Fixed(2))` makes a grid.

### Don't nest scroll directions the same way
A `LazyColumn` inside a `verticalScroll` Column crashes (infinite height). Use one scrolling container, or put other content as extra `item { }` blocks in the same `LazyColumn`.

### Adding and removing
```kotlin
val courses = remember { mutableStateListOf(Course(1, "Kotlin", "Ada")) }
Button(onClick = { courses.add(Course(courses.size + 1, "Compose", "Bola")) }) { Text("Add") }
```

### Item actions
Pass lambdas down: `CourseCard(course, onClick = { ... })`. The list owns the data, the item just reports taps.

### Empty state
```kotlin
if (courses.isEmpty()) Text("Nothing here yet") else CourseList(courses)
```

## Practice
Build the affirmations list: `projects/android/03-affirmations-list`.

## Knowledge check
- Why `LazyColumn` over `Column` for 500 items?
- What does `key` do?
- Why can't you put a `LazyColumn` inside a vertically scrolling `Column`?

## Additional resources
- [Lists and grids](https://developer.android.com/develop/ui/compose/lists)

Previous: [State and recomposition](03-state-recomposition.md) · Next: [Forms and the SABI auth screens](05-forms-and-auth-ui.md)
