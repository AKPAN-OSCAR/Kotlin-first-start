# Theming and Material 3

## Introduction
A design like SABI (yellow background, purple buttons, rounded shapes) should be defined once as a theme, not repeated on every screen.

## Learning outcomes
- Define a colour scheme, typography and shapes.
- Wrap your app in a theme.
- Read colours and text styles from `MaterialTheme`.

## Lesson

### The three pieces
`MaterialTheme(colorScheme = ..., typography = ..., shapes = ...)`

### Colours
```kotlin
private val SabiColors = lightColorScheme(
    primary = Color(0xFF7B16E8),
    onPrimary = Color.White,
    background = Color(0xFFFFEB1F),
    onBackground = Color(0xFF3D0C78),
    secondary = Color(0xFFFF9F1C),
    tertiary = Color(0xFF1DC98A),
)
```
`onX` is the colour of content drawn *on* X (text on a primary button).

### Typography
```kotlin
val Fredoka = FontFamily(Font(R.font.fredoka_bold, FontWeight.Bold))

val SabiTypography = Typography(
    headlineLarge = TextStyle(fontFamily = Fredoka, fontSize = 30.sp),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
)
```

### Shapes
```kotlin
val SabiShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(24.dp),
    large = RoundedCornerShape(32.dp),
)
```

### Putting it together
```kotlin
@Composable
fun SabiTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = SabiColors, typography = SabiTypography, shapes = SabiShapes, content = content)
}
```
Use it in `setContent { SabiTheme { App() } }`.

### Reading the theme
```kotlin
Text("Welcome", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.onBackground)
Button(onClick = {}) { Text("Go") }   // automatically uses primary / onPrimary
```
Never hard-code colours inside screens once you have a theme.

### Dark mode
Provide a `darkColorScheme` and choose with `isSystemInDarkTheme()`. A brand like SABI may choose to keep one scheme; that's a design decision.

### Dynamic colour
Android 12+ can derive a scheme from the wallpaper. For a strong brand, usually skip it.

## Practice
Move the colour constants in `projects/android/04-sabi-auth-ui` into a `SabiTheme`. Replace hard-coded `SabiPurple` uses with `MaterialTheme.colorScheme.primary`.

## Knowledge check
- What does `onPrimary` mean?
- Why define a theme once instead of colours in each screen?
- Which three objects does `MaterialTheme` take?

## Additional resources
- [Material 3 in Compose](https://developer.android.com/develop/ui/compose/designsystems/material3)
- [Material theme builder](https://material-foundation.github.io/material-theme-builder/)

Previous: [Composables, layouts and modifiers](01-composables-layouts-modifiers.md) · Next: [State and recomposition](03-state-recomposition.md)
