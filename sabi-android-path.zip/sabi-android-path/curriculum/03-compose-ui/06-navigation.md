# Navigation

## Introduction
Real apps have many screens. Navigation decides which screen is visible and what "back" does.

## Learning outcomes
- Navigate between screens with Navigation Compose (Nav2).
- Understand the idea behind Navigation 3 (the newer library).
- Handle the back stack in a login flow.

## Lesson

### Mental model
A **back stack** is a list of screens. Navigating *forward* pushes a screen; *back* pops one.

### Navigation Compose (Nav2): the established approach
Dependency: `androidx.navigation:navigation-compose`.
```kotlin
@Composable
fun SabiApp() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "welcome") {
        composable("welcome") {
            WelcomeScreen(
                onSignUpClick = { nav.navigate("signup") },
                onSignInClick = { nav.navigate("signin") }
            )
        }
        composable("signup") {
            SignUpScreen(
                onCreateAccount = { _, _, _ -> nav.navigate("home") { popUpTo("welcome") { inclusive = true } } },
                onSignInClick = { nav.navigate("signin") }
            )
        }
        composable("signin") { /* ... */ }
        composable("home") { Text("Home") }
    }
}
```
`popUpTo("welcome") { inclusive = true }` clears the auth screens, so pressing Back on Home exits the app instead of returning to sign-up.

### Passing arguments
```kotlin
composable("course/{id}") { entry ->
    val id = entry.arguments?.getString("id")
    CourseScreen(id)
}
nav.navigate("course/42")
```
Pass IDs, not big objects. Load the data in the destination.

### Navigation 3 (Nav3): the new library
Google released **Navigation 3** as a new Compose-first library (stable as of late 2025). Instead of a `NavController`, **you own the back stack as a list** and `NavDisplay` renders it.
```kotlin
data object Home
data class Product(val id: String)

val backStack = remember { mutableStateListOf<Any>(Home) }
NavDisplay(
    backStack = backStack,
    onBack = { backStack.removeLastOrNull() },
    entryProvider = { route ->
        when (route) {
            is Home -> NavEntry(route) { Button(onClick = { backStack.add(Product("123")) }) { Text("Open") } }
            is Product -> NavEntry(route) { Text("Product ${route.id}") }
            else -> error("Unknown route")
        }
    }
)
```
This is the shape shown in Google's announcement. The exact API (for example `entryProvider { }` DSL helpers) has settled since 1.0, so **follow the official guide when you adopt it**. Why learn Nav2 first? Most tutorials and existing apps use it, and the back-stack ideas carry over directly.

### Which should you use?
- Learning and the early projects: Nav2 is fine and well documented.
- New production apps: evaluate Nav3 using the official docs and recipes.

## Practice
Wire up Welcome → Sign up → Home in `projects/android/04-sabi-auth-ui` (`SabiApp.kt`). Then verify Back from Home closes the app.

## Knowledge check
- What is a back stack?
- Why `popUpTo(...) { inclusive = true }` after sign-up?
- What's the main idea that distinguishes Nav3 from Nav2?

## Additional resources
- [Navigation in Compose](https://developer.android.com/develop/ui/compose/navigation)
- [Navigation 3 guide](https://developer.android.com/guide/navigation/navigation-3)
- [Nav3 recipes repo](https://github.com/android/nav3-recipes)

Previous: [Forms and auth UI](05-forms-and-auth-ui.md) · Next: [ViewModel and UI state](../04-architecture/01-viewmodel-uistate.md)
