# Releasing to the Play Store

## Introduction
A finished app is one that real people can install. This lesson walks through the steps from your laptop to Google Play.

## Learning outcomes
- Prepare a release build.
- Sign an Android App Bundle.
- Understand Play Console basics and the testing tracks.

## Lesson

### 1. Prepare
- Unique `applicationId` (it can never change after publishing).
- Increase `versionCode` (integer, must go up each upload) and `versionName` (text like `1.0.0`).
- Launcher icon (Studio: *New → Image Asset*), app name, and real screenshots.
- Remove debug logs and test endpoints.
- Enable minification for release: `isMinifyEnabled = true` plus `isShrinkResources = true`, then test the release build thoroughly (ProGuard/R8 can remove needed code, fix with keep rules).

### 2. Signing
Android requires apps to be signed. In Studio: *Build → Generate Signed App Bundle / APK → Android App Bundle (.aab)*. Create a **keystore** and:
- Back it up somewhere safe. 
- **Never commit it.** (`*.jks` and `*.keystore` are in `.gitignore`.)
- Enrol in **Play App Signing** (default) so Google holds the final signing key and your upload key can be reset if lost.

### 3. Google Play Console
1. Create a [Play Console developer account](https://play.google.com/console) (one-time registration fee; identity verification is required).
2. Create the app, fill in the store listing (title, description, icon, screenshots).
3. Complete **App content**: privacy policy URL, Data safety form, content rating, target audience.
4. Upload your `.aab` to a track.

### 4. Testing tracks
- **Internal testing:** up to a small team, available fast.
- **Closed testing:** invited testers. New personal developer accounts may have to run a closed test with a minimum number of testers for a minimum period before production access, so check the current requirements early, since Google changes them.
- **Open testing / Production.**

### 5. After launch
Watch crash reports and ratings in the Play Console (Android vitals), ship small updates often, and reply to reviews.

### Alternatives while learning
Share a debug APK with friends through a file link to get quick feedback before going through Play.

## Practice
Generate a **signed bundle** of any project and keep the keystore safely **outside** the repo. You don't have to publish yet.

## Knowledge check
- Why must `versionCode` increase every upload?
- Why is the keystore never committed?
- What are the testing tracks for?

## Additional resources
- [Prepare your app for release](https://developer.android.com/studio/publish/preparing)
- [Sign your app](https://developer.android.com/studio/publish/app-signing)
- [Play Console help: testing](https://support.google.com/googleplay/android-developer/answer/9845334)

Previous: [Testing and debugging](01-testing-debugging.md) · Next: [Capstone](../08-capstone/01-capstone.md)
