# Testing and debugging

## Introduction
Tests let you change code without fear. Debugging skills save hours. Both are expected of working developers.

## Learning outcomes
- Write local unit tests for pure Kotlin and ViewModels.
- Write a basic Compose UI test.
- Use Logcat, breakpoints and the Layout Inspector.

## Lesson

### Test types
| Type | Runs on | Speed | Folder |
|---|---|---|---|
| Unit | your computer (JVM) | fast | `src/test` |
| Instrumented / UI | device or emulator | slower | `src/androidTest` |

Write many unit tests, fewer UI tests.

### Unit test example
```kotlin
class ValidatorsTest {
    @Test fun email_valid() = assertNull(Validators.email("ada@example.com"))
    @Test fun email_invalid() = assertNotNull(Validators.email("ada@"))
    @Test fun password_too_short() = assertEquals("Use at least 8 characters", Validators.password("abc1"))
}
```
Dependency: `testImplementation("junit:junit:<version>")`. Run with the gutter arrow next to the class.

### Testing a ViewModel with coroutines
Add `kotlinx-coroutines-test`. Replace the Main dispatcher in tests:
```kotlin
@OptIn(ExperimentalCoroutinesApi::class)
class MainDispatcherRule(private val d: TestDispatcher = UnconfinedTestDispatcher()) : TestWatcher() {
    override fun starting(description: Description) = Dispatchers.setMain(d)
    override fun finished(description: Description) = Dispatchers.resetMain()
}
```
Use `runTest { }` for suspend code, then assert on `viewModel.state.value`.

### Compose UI test
```kotlin
class SignUpScreenTest {
    @get:Rule val rule = createComposeRule()

    @Test fun createAccount_disabled_whenEmpty() {
        rule.setContent { SignUpScreen(onCreateAccount = { _, _, _ -> }, onSignInClick = {}) }
        rule.onNodeWithText("CREATE ACCOUNT").assertIsNotEnabled()
    }
}
```
(For this to pass, the button composable must expose its enabled state to semantics, for example by using `Button(enabled = ...)`. Making UI testable sometimes shapes how you build it.)

### Debugging toolkit
- **Logcat:** filter by your tag or package. `Log.d("Auth", "state=$state")`.
- **Breakpoints:** click the gutter, run with the bug icon, inspect variables.
- **Layout Inspector:** see the composable tree, and use recomposition counts to find wasteful redraws.
- **Read the stack trace:** find the first line from your package name.
- **Compose compiler/lint warnings:** fix them early.

### A debugging routine
1. Reproduce reliably. 2. Read the error. 3. Form a hypothesis. 4. Add a log or breakpoint. 5. Fix one thing. 6. Re-test.

## Practice
Run and extend the tests in `projects/android/05-signup-viewmodel`. Add a test for "passwords do not match".

## Knowledge check
- Where do unit tests and instrumented tests live?
- Why replace `Dispatchers.Main` in ViewModel tests?
- What does the Layout Inspector help you find?

## Additional resources
- [Testing on Android](https://developer.android.com/training/testing)
- [Test your Compose layout](https://developer.android.com/develop/ui/compose/testing)
- [Debug your app](https://developer.android.com/studio/debug)

Previous: [Validation and security](../06-auth-and-backend/02-validation-security.md) · Next: [Releasing to the Play Store](02-release-play-store.md)
