# Repository and app layers

## Introduction
As an app grows you need a clear place for each kind of code. Google's recommended architecture has a **UI layer** and a **data layer** (and an optional domain layer).

## Learning outcomes
- Describe the UI, domain and data layers.
- Write a repository that hides data sources.
- Keep ViewModels independent from Retrofit/Room/Firebase.

## Lesson

### Layers
```
UI layer      Composables + ViewModel        (shows state, handles events)
Domain layer  Use cases (optional)           (reusable business rules)
Data layer    Repositories + data sources    (network, database, files)
```
Arrows point down only: UI knows the data layer; the data layer knows nothing about UI.

### A repository
```kotlin
interface AuthRepository {
    suspend fun signUp(name: String, email: String, password: String): Result<Unit>
    suspend fun signIn(email: String, password: String): Result<Unit>
}

class FakeAuthRepository : AuthRepository {
    override suspend fun signUp(name: String, email: String, password: String): Result<Unit> {
        delay(800)
        return if (email.endsWith("@example.com")) Result.failure(Exception("Email taken"))
        else Result.success(Unit)
    }
    override suspend fun signIn(email: String, password: String) = Result.success(Unit)
}
```
Start with a **fake**. Your UI and ViewModel are fully built and tested before you add Firebase (lesson 06). Swapping the implementation changes nothing above.

### ViewModel using the repository
```kotlin
class SignUpViewModel(private val repo: AuthRepository) : ViewModel() {
    // ...
    fun submit() = viewModelScope.launch {
        _state.update { it.copy(isLoading = true, error = null) }
        repo.signUp(state.value.name, state.value.email, state.value.password)
            .onSuccess { _state.update { s -> s.copy(isLoading = false, signedUp = true) } }
            .onFailure { e -> _state.update { s -> s.copy(isLoading = false, error = e.message) } }
    }
}
```

### Single source of truth
One layer owns each piece of data. A common pattern: the database is the source of truth, the repository refreshes it from the network, and the UI observes the database `Flow`.

### Mappers
Keep network models (`UserDto`) separate from UI models (`User`) and convert between them in the repository.

### Why this matters for learners
You can ship screens without a backend, and testing is easy because you can inject a fake.

## Practice
Add `AuthRepository` and the fake to `projects/android/05-signup-viewmodel`, and make `submit()` show a loading spinner and an error message.

## Knowledge check
- Why define `AuthRepository` as an interface?
- Which layer should know about Retrofit?
- What is a "single source of truth"?

## Additional resources
- [Data layer guide](https://developer.android.com/topic/architecture/data-layer)
- [Domain layer guide](https://developer.android.com/topic/architecture/domain-layer)

Previous: [Coroutines and Flow](02-coroutines-flow.md) · Next: [Dependency injection with Hilt](04-hilt-di.md)
