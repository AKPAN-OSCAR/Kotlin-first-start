# ViewModel and UI state

## Introduction
Putting logic inside composables gets messy fast and breaks on rotation. A **ViewModel** holds screen state and logic, survives configuration changes, and keeps composables simple.

## Learning outcomes
- Create a ViewModel exposing a `StateFlow` of UI state.
- Collect it in Compose with `collectAsStateWithLifecycle`.
- Send events up as function calls.

## Lesson

### UI state as one data class
```kotlin
data class SignUpUiState(
    val name: String = "",
    val email: String = "",
    val password: String = "",
    val confirm: String = "",
    val isLoading: Boolean = false,
    val error: String? = null,
)
```

### The ViewModel
```kotlin
class SignUpViewModel : ViewModel() {
    private val _state = MutableStateFlow(SignUpUiState())
    val state: StateFlow<SignUpUiState> = _state.asStateFlow()

    fun onNameChange(v: String) = _state.update { it.copy(name = v) }
    fun onEmailChange(v: String) = _state.update { it.copy(email = v) }
    fun onPasswordChange(v: String) = _state.update { it.copy(password = v) }
    fun onConfirmChange(v: String) = _state.update { it.copy(confirm = v) }
}
```
- Private mutable, public read-only: only the ViewModel changes state.
- `update { it.copy(...) }` replaces the state with a new immutable copy.

### Using it in a screen
Dependencies: `androidx.lifecycle:lifecycle-viewmodel-compose` and `lifecycle-runtime-compose`.
```kotlin
@Composable
fun SignUpRoute(viewModel: SignUpViewModel = viewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    SignUpScreen(
        state = state,
        onNameChange = viewModel::onNameChange,
        onEmailChange = viewModel::onEmailChange,
        /* ... */
    )
}
```
Split into a **route** (knows the ViewModel) and a **screen** (pure UI, takes state + callbacks). The screen is previewable and testable.

### Data flow
```
User taps -> Screen calls onX -> ViewModel updates StateFlow -> Screen recomposes
```
This loop is called **unidirectional data flow (UDF)**.

### One-off events
Navigation or snackbars are not state you want repeated after rotation. Model them as state that the UI "consumes" (for example `val navigateHome: Boolean`, reset after handling), or use a `Channel`. Keep it simple first.

### Don't leak the Context
Never store an Activity or View in a ViewModel.

## Practice
Refactor the SABI sign-up screen to take a `SignUpUiState` and callbacks: `projects/android/05-signup-viewmodel`. Run the included unit tests.

## Knowledge check
- Why expose `StateFlow` but keep `MutableStateFlow` private?
- What survives rotation: a `remember` value or a ViewModel field?
- What are the roles of the Route and Screen composables?

## Additional resources
- [ViewModel overview](https://developer.android.com/topic/libraries/architecture/viewmodel)
- [UI layer / state holders](https://developer.android.com/topic/architecture/ui-layer)
- [Guide to app architecture](https://developer.android.com/topic/architecture)

Previous: [Navigation](../03-compose-ui/06-navigation.md) · Next: [Coroutines and Flow](02-coroutines-flow.md)
