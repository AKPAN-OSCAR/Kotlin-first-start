# Coroutines and Flow

## Introduction
Network and disk work must never block the main thread (the UI freezes). Coroutines let you write asynchronous code that reads like normal code. Flow streams values over time.

## Learning outcomes
- Launch coroutines from a ViewModel.
- Write `suspend` functions and switch dispatchers.
- Expose and collect a `Flow`.
- Handle errors with `try/catch`.

## Lesson

### suspend functions
```kotlin
suspend fun fetchUser(): User {
    delay(1000)               // suspends without blocking the thread
    return User("Ada", "ada@example.com")
}
```
A `suspend` function can only be called from another suspend function or a coroutine.

### Launching
```kotlin
class ProfileViewModel : ViewModel() {
    private val _state = MutableStateFlow<LoadState>(LoadState.Loading)
    val state = _state.asStateFlow()

    init {
        viewModelScope.launch {
            _state.value = try {
                LoadState.Success(listOf(fetchUser().name))
            } catch (e: Exception) {
                LoadState.Error(e.message ?: "Something went wrong")
            }
        }
    }
}
```
`viewModelScope` cancels automatically when the ViewModel is cleared.

### Dispatchers
- `Dispatchers.Main`: UI.
- `Dispatchers.IO`: disk and network.
- `Dispatchers.Default`: CPU-heavy work.
```kotlin
suspend fun readFile(): String = withContext(Dispatchers.IO) { /* blocking read */ "..." }
```
Libraries like Room and Retrofit already switch threads for their suspend functions.

### Flow
```kotlin
fun ticker(): Flow<Int> = flow {
    var i = 0
    while (true) { emit(i++); delay(1000) }
}

viewModelScope.launch {
    ticker().map { it * 2 }.collect { println(it) }
}
```
- `Flow` is cold: nothing runs until collected.
- `StateFlow` is hot: always has a current value; perfect for UI state.
- `stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), initial)` converts a Flow into a StateFlow for the UI.

### Structured concurrency
Coroutines run inside a scope; cancelling the scope cancels its children. This prevents leaks. Don't use `GlobalScope`.

### Cancellation and exceptions
Never swallow `CancellationException`. If you catch `Exception`, rethrow it when it's a cancellation:
```kotlin
catch (e: CancellationException) { throw e }
```

## Practice
Complete `projects/kotlin-exercises/exercises/05_coroutines_flow.kt` (uses `kotlinx-coroutines`, see the file header for setup).

## Knowledge check
- Why shouldn't you do a network call on the main thread?
- What's the difference between `Flow` and `StateFlow`?
- What does `viewModelScope` do for you?

## Additional resources
- [Coroutines on Android](https://developer.android.com/kotlin/coroutines)
- [Kotlin Flow on Android](https://developer.android.com/kotlin/flow)
- [Coroutines guide](https://kotlinlang.org/docs/coroutines-guide.html)

Previous: [ViewModel and UI state](01-viewmodel-uistate.md) · Next: [Repository and app layers](03-repository-layers.md)
