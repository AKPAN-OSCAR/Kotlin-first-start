# Dependency injection with Hilt

## Introduction
`SignUpViewModel(repo)` needs someone to supply the repository. **Dependency injection (DI)** means objects receive their dependencies instead of creating them. Hilt is Google's recommended DI library for Android.

## Learning outcomes
- Explain DI with a plain Kotlin example.
- Set up Hilt and inject a repository into a ViewModel.
- Provide a different implementation for tests.

## Lesson

### DI without a library
```kotlin
class SignUpViewModel(private val repo: AuthRepository)   // gets it from outside
// vs. the hard-wired version you want to avoid:
// private val repo = FirebaseAuthRepository()
```
A hand-written factory also works for small apps, but gets repetitive.

### Hilt setup (summary)
1. Add the Hilt Gradle plugin, the `hilt-android` dependency and `ksp`/`kapt` compiler (follow the current setup page, versions change).
2. Annotate the Application:
```kotlin
@HiltAndroidApp
class SabiApplication : Application()
```
Register it in the manifest: `android:name=".SabiApplication"`.
3. Annotate the Activity:
```kotlin
@AndroidEntryPoint
class MainActivity : ComponentActivity() { /* ... */ }
```

### Providing implementations
```kotlin
@Module
@InstallIn(SingletonComponent::class)
abstract class AuthModule {
    @Binds abstract fun bindAuthRepo(impl: FakeAuthRepository): AuthRepository
}

class FakeAuthRepository @Inject constructor() : AuthRepository { /* ... */ }
```
`@Binds` says "when someone asks for `AuthRepository`, give them `FakeAuthRepository`." Later swap in `FirebaseAuthRepository` by changing one line.

### Injecting into a ViewModel
```kotlin
@HiltViewModel
class SignUpViewModel @Inject constructor(private val repo: AuthRepository) : ViewModel()

@Composable
fun SignUpRoute(viewModel: SignUpViewModel = hiltViewModel()) { /* ... */ }
```
`hiltViewModel()` needs `androidx.hilt:hilt-navigation-compose`.

### In tests
Create the ViewModel directly with a fake: `SignUpViewModel(FakeAuthRepository())`. No Hilt needed for plain unit tests.

### Is Hilt required?
No. Use manual DI while learning if the setup overwhelms you, then add Hilt when you feel the pain. Koin is a popular alternative.

## Practice
Optionally add Hilt to `05-signup-viewmodel` following the official setup page. If you skip it, make a `SignUpViewModelFactory` by hand.

## Knowledge check
- What problem does DI solve?
- What does `@Binds` do?
- How do you test a ViewModel that depends on a repository?

## Additional resources
- [Dependency injection on Android](https://developer.android.com/training/dependency-injection)
- [Hilt](https://developer.android.com/training/dependency-injection/hilt-android)

Previous: [Repository and layers](03-repository-layers.md) · Next: [Room database](../05-data-and-networking/01-room.md)
