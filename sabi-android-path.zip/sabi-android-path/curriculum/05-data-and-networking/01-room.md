# Room database

## Introduction
Room is Android's SQLite wrapper. Use it for structured data that must survive app restarts and work offline (notes, saved courses, cached lists).

## Learning outcomes
- Define an Entity, DAO and Database.
- Observe query results as a `Flow`.
- Write results from a ViewModel on a background thread.

## Lesson

### Dependencies
Room needs the **KSP** plugin for its compiler. Add `room-runtime`, `room-ktx` and `ksp("androidx.room:room-compiler:<version>")`. Check the [Room release page](https://developer.android.com/jetpack/androidx/releases/room) for the current version.

### Entity
```kotlin
@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String,
    val createdAt: Long = System.currentTimeMillis(),
)
```

### DAO
```kotlin
@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<Note>>

    @Insert suspend fun insert(note: Note)
    @Delete suspend fun delete(note: Note)
}
```
A `Flow` return type means the UI updates automatically whenever the table changes.

### Database
```kotlin
@Database(entities = [Note::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun noteDao(): NoteDao
}

val db = Room.databaseBuilder(context, AppDatabase::class.java, "sabi.db").build()
```
Create **one** database instance (a singleton via Hilt or your Application class).

### ViewModel + UI
```kotlin
class NotesViewModel(private val dao: NoteDao) : ViewModel() {
    val notes = dao.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun add(title: String, body: String) = viewModelScope.launch { dao.insert(Note(title = title, body = body)) }
}
```
Collect `notes` with `collectAsStateWithLifecycle()` and show with `LazyColumn`.

### Migrations
Changing a table means bumping `version` and supplying a `Migration`, otherwise users lose data (or the app crashes). Plan for it before you publish.

## Practice
Build the notes app: `projects/android/06-notes-room`.

## Knowledge check
- What do Entity, DAO and Database each represent?
- Why return `Flow` from a query?
- Why do you need a migration when you change a table?

## Additional resources
- [Room overview](https://developer.android.com/training/data-storage/room)
- [Migrate your database](https://developer.android.com/training/data-storage/room/migrating-db-versions)

Previous: [Hilt](../04-architecture/04-hilt-di.md) · Next: [DataStore](02-datastore.md)
