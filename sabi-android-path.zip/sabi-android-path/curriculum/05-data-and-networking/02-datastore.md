# DataStore

## Introduction
For small settings (dark mode, "has seen onboarding", a logged-in flag) use **DataStore**. It replaces SharedPreferences with a safe, asynchronous, Flow-based API.

## Learning outcomes
- Create a Preferences DataStore.
- Read values as a Flow and write them in a coroutine.
- Choose between Room and DataStore.

## Lesson

### Setup
Dependency: `androidx.datastore:datastore-preferences`.
```kotlin
val Context.dataStore by preferencesDataStore(name = "settings")

object Keys {
    val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
}
```
Declare the `dataStore` extension once at the top level of a file.

### Reading and writing
```kotlin
class SettingsRepository(private val context: Context) {
    val onboardingDone: Flow<Boolean> =
        context.dataStore.data.map { prefs -> prefs[Keys.ONBOARDING_DONE] ?: false }

    suspend fun setOnboardingDone(done: Boolean) {
        context.dataStore.edit { prefs -> prefs[Keys.ONBOARDING_DONE] = done }
    }
}
```

### Use case: first-run screen
In your start destination, collect `onboardingDone`. If false, show the Welcome screen; if true, skip to Home.

### Room vs DataStore
| Need | Use |
|---|---|
| A few key-value settings | DataStore |
| Lists, relationships, queries | Room |
| Secrets (tokens) | Encrypted storage / Keystore, not plain DataStore |

### Gotcha
Never read DataStore on the main thread with blocking calls. Always use the `Flow` or `first()` inside a coroutine.

## Practice
Add an "onboarding done" flag to `04-sabi-auth-ui`: show Welcome only on first launch.

## Knowledge check
- Why is DataStore better than SharedPreferences?
- Which would you use for a list of notes?
- Where should an auth token **not** be stored?

## Additional resources
- [DataStore](https://developer.android.com/topic/libraries/architecture/datastore)

Previous: [Room](01-room.md) · Next: [Networking with Retrofit](03-networking-retrofit.md)
