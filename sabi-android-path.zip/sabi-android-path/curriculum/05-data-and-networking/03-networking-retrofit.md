# Networking with Retrofit

## Introduction
Most apps talk to a server. **Retrofit** turns an HTTP API into a Kotlin interface; **kotlinx.serialization** (or Moshi) converts JSON to Kotlin objects; **Coil** loads images.

## Learning outcomes
- Declare an API with Retrofit.
- Parse JSON into data classes.
- Handle loading, success and error in the UI.
- Load remote images with Coil.

## Lesson

### Permission
`AndroidManifest.xml`: `<uses-permission android:name="android.permission.INTERNET" />`

### Dependencies
`retrofit`, a converter (for example the kotlinx.serialization converter) and the `kotlin-serialization` Gradle plugin, plus `io.coil-kt.coil3:coil-compose` for images. Check each library's page for current versions.

### Model and API
```kotlin
@Serializable
data class PostDto(val id: Int, val title: String, val body: String)

interface PostApi {
    @GET("posts")
    suspend fun getPosts(): List<PostDto>
}
```

### Building Retrofit
```kotlin
val json = Json { ignoreUnknownKeys = true }
val retrofit = Retrofit.Builder()
    .baseUrl("https://jsonplaceholder.typicode.com/")
    .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
    .build()
val api = retrofit.create(PostApi::class.java)
```
[jsonplaceholder.typicode.com](https://jsonplaceholder.typicode.com) is a free fake API for practice.

### Repository + UI state
```kotlin
class PostRepository(private val api: PostApi) {
    suspend fun posts(): Result<List<PostDto>> = runCatching { api.getPosts() }
}
```
Expose `LoadState` (Loading / Success / Error) from the ViewModel and render with `when`. Always show a retry button on error.

### Images
```kotlin
AsyncImage(model = "https://example.com/pic.jpg", contentDescription = null)
```

### Real-world concerns
- Slow or no network is normal: show states, cache with Room, retry.
- Don't put API keys in your source code. Anything inside the app can be extracted.
- Use HTTPS only.

## Practice
Extend `06-notes-room` (or a new app) to fetch and display posts from JSONPlaceholder with loading and error states.

## Knowledge check
- What does `@GET("posts")` declare?
- Why `ignoreUnknownKeys = true`?
- Why shouldn't API secrets live in your APK?

## Additional resources
- [Retrofit](https://square.github.io/retrofit/)
- [kotlinx.serialization](https://kotlinlang.org/docs/serialization.html)
- [Coil](https://coil-kt.github.io/coil/)

Previous: [DataStore](02-datastore.md) · Next: [Firebase Authentication](../06-auth-and-backend/01-firebase-auth.md)
