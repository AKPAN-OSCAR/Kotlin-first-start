# Capstone: build your SABI feature

## Introduction
You have now seen every layer of a modern Android app. The capstone is where you prove it by building something real from a blank folder.

## Learning outcomes
- Plan a small app with a user story and screen list.
- Combine UI, ViewModel, repository, local data and auth.
- Ship a tested, documented project.

## The brief
Build **SABI v0.1**, a study app for students. Required:

1. **Auth:** Welcome, Create Account, Sign in (Firebase or fake repository), sign out.
2. **Home:** list of study "topics" (Room) with add, edit, delete.
3. **Detail:** a topic screen with notes and a simple study timer.
4. **Settings:** a dark-mode or reminder toggle stored in DataStore.
5. **Architecture:** ViewModel + UiState per screen, a repository per data source.
6. **Quality:** at least 8 unit tests (validators, ViewModels) and one Compose UI test.
7. **Polish:** loading, empty and error states on every list/screen.
8. **Repo:** clear README with screenshots, setup steps and what you learned.

### Stretch goals (pick any)
- Fetch a motivational quote from a public API (Retrofit).
- Push reminders with WorkManager.
- Adaptive layout for tablets.
- Migrate to Navigation 3.
- Publish to an internal test track.

## Steps
1. **Plan (1 day).** Write user stories ("As a student I can add a topic"), sketch screens on paper, list data models.
2. **Skeleton (1 day).** Theme, navigation graph with empty screens.
3. **Vertical slices.** Finish one feature end-to-end (UI → ViewModel → repo → data) before starting the next.
4. **Tests as you go.**
5. **Polish and release build.**
6. **Write the README and record a short demo.**

## Self-review checklist
- [ ] No business logic inside composables.
- [ ] State flows down, events flow up.
- [ ] No secrets or `google-services.json` committed.
- [ ] Works after rotation and process death.
- [ ] Every user-visible string is in `strings.xml`.
- [ ] Content descriptions on meaningful images and icons (accessibility).
- [ ] Release build tested.

## Knowledge check
Explain, from memory, how a tap on "Create Account" ends up as a signed-in user on the Home screen, naming each class involved.

## Additional resources
- [Now in Android (Google's reference app)](https://github.com/android/nowinandroid)
- [Android architecture samples](https://github.com/android/architecture-samples)

Previous: [Releasing](../07-quality-and-shipping/02-release-play-store.md) · Next: [Glossary and resources](../09-resources/glossary-and-resources.md)
