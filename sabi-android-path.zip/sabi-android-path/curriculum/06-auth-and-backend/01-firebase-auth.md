# Firebase Authentication

## Introduction
Never build password storage yourself. A service like Firebase Authentication handles accounts, password hashing, email verification and password reset. You call a few functions.

## Learning outcomes
- Create a Firebase project and connect your app.
- Implement email/password sign-up and sign-in behind your `AuthRepository`.
- Observe the signed-in state.

## Lesson

### 1. Create the project
1. Go to the [Firebase console](https://console.firebase.google.com), create a project.
2. Add an Android app using your exact `applicationId`.
3. Download `google-services.json` into `app/`. **Do not commit it to a public repo** (it's in this repo's `.gitignore`).
4. In **Authentication → Sign-in method**, enable **Email/Password**.
5. Add the Google services Gradle plugin and the Firebase Auth dependency (use the Firebase BoM). Follow the [current setup guide](https://firebase.google.com/docs/android/setup), since versions change.

### 2. The repository
```kotlin
class FirebaseAuthRepository @Inject constructor() : AuthRepository {
    private val auth = FirebaseAuth.getInstance()

    override suspend fun signUp(name: String, email: String, password: String): Result<Unit> = runCatching {
        val result = auth.createUserWithEmailAndPassword(email, password).await()
        result.user?.updateProfile(userProfileChangeRequest { displayName = name })?.await()
        Unit
    }

    override suspend fun signIn(email: String, password: String): Result<Unit> = runCatching {
        auth.signInWithEmailAndPassword(email, password).await()
        Unit
    }
}
```
`.await()` comes from `kotlinx-coroutines-play-services`.

### 3. Observing auth state
```kotlin
val isSignedIn: Flow<Boolean> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { trySend(it.currentUser != null) }
    auth.addAuthStateListener(listener)
    awaitClose { auth.removeAuthStateListener(listener) }
}
```
Use it to choose the start destination: signed in → Home, otherwise Welcome.

### 4. Friendly errors
Map exceptions to messages: `FirebaseAuthWeakPasswordException`, `FirebaseAuthInvalidCredentialsException`, `FirebaseAuthUserCollisionException` ("email already in use"). Show them in the form.

### 5. Other things you'll want
Password reset (`sendPasswordResetEmail`), email verification, Google sign-in (Credential Manager), sign-out.

### Alternatives
Supabase, Appwrite, or your own backend. The `AuthRepository` interface means switching doesn't change your UI.

## Practice
Swap `FakeAuthRepository` for `FirebaseAuthRepository` in your SABI project and test sign-up with a real email.

## Knowledge check
- Why not store passwords yourself?
- Why is `google-services.json` kept out of public repos?
- How do you choose the first screen based on login state?

## Additional resources
- [Firebase Auth on Android](https://firebase.google.com/docs/auth/android/start)
- [Android Basics with Compose and Firebase (course)](https://developer.android.com/courses/android-basics-compose-firebase/course)

Previous: [Retrofit](../05-data-and-networking/03-networking-retrofit.md) · Next: [Validation and security](02-validation-security.md)
