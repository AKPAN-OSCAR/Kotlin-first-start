# Validation and security basics

## Introduction
Good sign-up screens give instant, kind feedback, and apps must protect user data. This lesson covers both at a beginner level.

## Learning outcomes
- Write small, testable validators.
- Show errors at the right time.
- Apply basic mobile security habits.

## Lesson

### Validators are plain Kotlin
```kotlin
object Validators {
    private val email = Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")

    fun name(v: String): String? = if (v.isBlank()) "Enter your full name" else null
    fun email(v: String): String? = if (!email.matches(v.trim())) "Enter a valid email" else null
    fun password(v: String): String? = when {
        v.length < 8 -> "Use at least 8 characters"
        v.none { it.isDigit() } -> "Include a number"
        else -> null
    }
    fun confirm(p: String, c: String): String? = if (p != c) "Passwords do not match" else null
}
```
A function returns `null` when valid, or an error message. Because it's pure Kotlin, it is trivial to unit-test.

### When to show errors
- Don't scream at users on the first keystroke.
- Show an error after the field loses focus, or after pressing the submit button once.
- Keep the message specific and polite.

### Server rules win
Client validation is for convenience. The backend (Firebase) enforces the real rules, so always handle server errors too.

### Security habits
1. **No secrets in the app.** API keys and passwords inside an APK can be extracted.
2. **Use HTTPS only.** Cleartext traffic is blocked by default on modern Android; keep it that way.
3. **Don't log sensitive data.** Never `Log.d` passwords or tokens.
4. **Store tokens safely.** Prefer the platform's secure storage (Android Keystore, EncryptedSharedPreferences successors) over plain files.
5. **Minimal permissions.** Ask only for what you need, at the moment you need it.
6. **Don't commit credentials.** `google-services.json`, keystores and `local.properties` stay out of Git.
7. **Keep dependencies updated** to get security fixes.
8. **Prefer proven auth** (Firebase Auth, Credential Manager, passkeys) over custom code.

### Privacy
If you collect personal data, Google Play requires a privacy policy and a Data safety form. Collect less, and delete on request.

## Practice
Write `Validators`, wire them into the sign-up ViewModel, and add unit tests (`projects/android/05-signup-viewmodel/app/src/test`).

## Knowledge check
- Why are validators written as plain functions?
- Why is client-side validation not enough?
- Name three things that must never be committed to Git.

## Additional resources
- [App security best practices](https://developer.android.com/privacy-and-security/security-tips)
- [Credential Manager / passkeys](https://developer.android.com/identity/sign-in/credential-manager)
- [OWASP Mobile Top 10](https://owasp.org/www-project-mobile-top-10/)

Previous: [Firebase Authentication](01-firebase-auth.md) · Next: [Testing and debugging](../07-quality-and-shipping/01-testing-debugging.md)
