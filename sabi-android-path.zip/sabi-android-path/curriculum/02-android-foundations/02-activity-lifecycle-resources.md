# Activities, lifecycle and resources

## Introduction
An Activity is the window that hosts your Compose UI. Android can destroy and recreate it (rotation, low memory, dark-mode switch), so you must understand its lifecycle. Resources keep strings, colours and images out of your code.

## Learning outcomes
- Explain the Activity lifecycle.
- Set Compose content with `setContent`.
- Use string, colour and drawable resources, and add a custom font.

## Lesson

### A minimal Activity
```kotlin
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme {
                Text("Hello SABI")
            }
        }
    }
}
```
It must also be declared in `AndroidManifest.xml` (Studio does this for you).

### Lifecycle
`onCreate → onStart → onResume` (visible and interactive) → `onPause → onStop → onDestroy`.

- **Configuration change** (rotation, language, dark mode) destroys and recreates the Activity. Plain variables are lost.
- Compose's `rememberSaveable` and the **ViewModel** (lesson 04) survive this.
- You rarely override every callback in Compose apps, but knowing the order explains many bugs.

### Resources
Everything in `res/`:
```
res/values/strings.xml    <string name="app_name">SABI</string>
res/values/colors.xml
res/drawable/             <- PNG, WebP, vector XML
res/font/                 <- fonts (e.g. fredoka.ttf)
res/mipmap/               <- launcher icons
```
Use them in Compose:
```kotlin
Text(stringResource(R.string.app_name))
Image(painterResource(R.drawable.sabi_logo), contentDescription = "SABI logo")
```
Why strings in resources? Translation and one place to change text. Image names must be lowercase with underscores (`sabi_logo.png`).

### Custom fonts
Put `fredoka_bold.ttf` in `res/font/`, then:
```kotlin
val Fredoka = FontFamily(Font(R.font.fredoka_bold, FontWeight.Bold))
```
(Free fonts at [fonts.google.com](https://fonts.google.com).)

### Permissions and Intents (preview)
Network use needs `<uses-permission android:name="android.permission.INTERNET"/>` in the manifest. You'll use that in lesson 05.

## Practice
1. Move your Hello text into `strings.xml` and use `stringResource`.
2. Add a log line in `onCreate` (`Log.d("Lifecycle", "onCreate")`), rotate the emulator, and watch Logcat.

## Knowledge check
- What happens to a normal `var` when you rotate the device?
- Why put strings in `strings.xml`?
- Which two things survive a configuration change?

## Additional resources
- [Activity lifecycle](https://developer.android.com/guide/components/activities/activity-lifecycle)
- [App resources overview](https://developer.android.com/guide/topics/resources/providing-resources)
- [Fonts in Compose](https://developer.android.com/develop/ui/compose/text/fonts)

Previous: [Project structure](01-project-structure-gradle.md) · Next: [Composables, layouts and modifiers](../03-compose-ui/01-composables-layouts-modifiers.md)
