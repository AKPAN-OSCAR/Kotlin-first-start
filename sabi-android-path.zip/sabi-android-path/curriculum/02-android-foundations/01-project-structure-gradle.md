# Project structure and Gradle

## Introduction
Before building features you must know where things live and how an app is assembled. Gradle is the build tool that turns your Kotlin and resources into an installable app.

## Learning outcomes
- Navigate an Android project.
- Read a `build.gradle.kts` and a version catalog.
- Add a dependency and sync.

## Lesson

### The structure
```
MyApp/
├── app/
│   ├── build.gradle.kts            <- module build file (dependencies live here)
│   └── src/main/
│       ├── AndroidManifest.xml     <- app identity, permissions, entry Activity
│       ├── java/com/example/myapp/ <- Kotlin source (folder is called java, holds .kt)
│       └── res/                    <- resources: drawable, values, font, mipmap
├── build.gradle.kts                <- project-level build file
├── settings.gradle.kts             <- which modules exist
└── gradle/libs.versions.toml       <- version catalog: all dependency versions in one place
```

### Key files
- **AndroidManifest.xml:** declares the app, the launcher Activity and permissions such as `<uses-permission android:name="android.permission.INTERNET" />`.
- **app/build.gradle.kts:** `applicationId`, `minSdk`, `targetSdk`, `compileSdk`, plugins and `dependencies { }`.
- **libs.versions.toml:** one place to change versions.

### Adding a dependency
In `libs.versions.toml`:
```toml
[libraries]
androidx-lifecycle-viewmodel-compose = { group = "androidx.lifecycle", name = "lifecycle-viewmodel-compose", version.ref = "lifecycle" }
```
In `app/build.gradle.kts`:
```kotlin
dependencies {
    implementation(libs.androidx.lifecycle.viewmodel.compose)
}
```
Click **Sync Now**. Studio's *File → Project Structure → Dependencies* dialog can also add libraries for you.

### The Compose BOM
Compose has many artifacts. The **BOM** (Bill of Materials) pins them to versions known to work together:
```kotlin
implementation(platform(libs.androidx.compose.bom))
implementation("androidx.compose.material3:material3")   // no version needed
```

### Build types
`debug` (default, for development) and `release` (minified, signed, for the Play Store). You'll meet release in lesson 07.

## Practice
In your `HelloAndroid` project: open every file listed above, find `applicationId`, `minSdk` and the BOM line, and write one sentence about what each does in your notes.

## Knowledge check
- Where do you add a library?
- What does the Compose BOM do?
- What's the difference between `debug` and `release` builds?

## Additional resources
- [App fundamentals](https://developer.android.com/guide/components/fundamentals)
- [Configure your build](https://developer.android.com/build)
- [Version catalogs](https://docs.gradle.org/current/userguide/platforms.html)

Previous: [Collections and lambdas](../01-kotlin-foundations/04-collections-lambdas.md) · Next: [Activities, lifecycle and resources](02-activity-lifecycle-resources.md)
