# Glossary and further reading

## Glossary
| Term | Meaning |
|---|---|
| **Activity** | The window/screen host for your app UI. |
| **APK / AAB** | Installable package / Play Store upload format. |
| **Back stack** | The list of screens a user can go back through. |
| **BOM** | Bill of Materials; pins related library versions together. |
| **Composable** | A function that emits UI in Jetpack Compose. |
| **Coroutine** | Lightweight asynchronous task in Kotlin. |
| **DAO** | Data Access Object; Room's query interface. |
| **DI** | Dependency injection; objects receive their dependencies. |
| **Flow / StateFlow** | Streams of values over time; StateFlow always holds a current value. |
| **Gradle** | The build system. |
| **Hoisting** | Moving state up to a parent and passing it down. |
| **Manifest** | `AndroidManifest.xml`; the app's declaration file. |
| **Modifier** | Chain of decorations/behaviours on a composable. |
| **Recomposition** | Compose re-running composables when state changes. |
| **Repository** | Class that hides where data comes from. |
| **Sealed type** | A closed set of subtypes, great for UI states. |
| **UDF** | Unidirectional data flow: state down, events up. |
| **ViewModel** | Holds screen state and survives configuration changes. |

## Official learning
- [Android Basics with Compose](https://developer.android.com/courses/android-basics-compose/course) (free course by Google)
- [Android Basics with Compose and Firebase](https://developer.android.com/courses/android-basics-compose-firebase/course)
- [Jetpack Compose pathway](https://developer.android.com/courses/pathways/compose)
- [Kotlin docs and Koans](https://kotlinlang.org/docs/getting-started.html)
- [Now in Android sample](https://github.com/android/nowinandroid)
- [Compose samples](https://github.com/android/compose-samples)

## Staying current
- [Android Developers Blog](https://android-developers.googleblog.com/)
- [Kotlin Blog](https://blog.jetbrains.com/kotlin/)
- [Jetpack release notes](https://developer.android.com/jetpack/androidx/versions)

## Community
Ask good questions: include what you tried, the exact error and a minimal code sample.
- Stack Overflow (`android-jetpack-compose`, `kotlin` tags)
- r/androiddev, Kotlin Slack, local GDG / developer meetups

## Habits that make you hireable
- Push to GitHub weekly. A green commit history is a portfolio.
- Read other people's code (the samples above).
- Write READMEs with screenshots.
- Build something you personally need.
