# 05 Sign-up with a ViewModel (and tests)

**Lessons:** [ViewModel and UI state](../../../curriculum/04-architecture/01-viewmodel-uistate.md), [Repository and layers](../../../curriculum/04-architecture/03-repository-layers.md), [Validation and security](../../../curriculum/06-auth-and-backend/02-validation-security.md), [Testing](../../../curriculum/07-quality-and-shipping/01-testing-debugging.md)

## What you build
A sign-up form with a proper architecture:

```
SignUpRoute (finds ViewModel)  ->  SignUpScreen (pure UI)
        |
   SignUpViewModel (StateFlow<SignUpUiState>)
        |
   AuthRepository (interface)  <-  FakeAuthRepository now, Firebase later
        |
   Validators (plain Kotlin, unit-tested)
```

## Files
| File | Layer |
|---|---|
| `Validators.kt` | pure logic |
| `SignUpUiState.kt` | state model |
| `AuthRepository.kt` | data layer interface + fake |
| `SignUpViewModel.kt` | UI logic |
| `SignUpScreen.kt` | composables (Route + Screen) |
| `src/test/.../ValidatorsTest.kt` | unit tests |
| `src/test/.../SignUpViewModelTest.kt` | ViewModel tests with coroutines |

## Dependencies
```kotlin
implementation("androidx.lifecycle:lifecycle-viewmodel-compose:<version>")
implementation("androidx.lifecycle:lifecycle-runtime-compose:<version>")
testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:<version>")
```
(`junit` is already there from the Empty Activity template.)

## Challenges
1. Run all tests. Break a validator on purpose and watch a test fail.
2. Add a rule "password must contain an uppercase letter" test-first (write the test, watch it fail, then implement).
3. Plug the visual design from project 04 into `SignUpScreen` (keep the callbacks the same).
4. Add `signIn` flow and a `SignInViewModel`.
5. Swap `FakeAuthRepository` for a Firebase implementation (lesson 06-01).
