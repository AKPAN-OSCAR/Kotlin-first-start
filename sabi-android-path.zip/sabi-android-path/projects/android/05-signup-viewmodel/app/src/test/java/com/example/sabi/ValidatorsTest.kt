package com.example.sabi

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class ValidatorsTest {

    // name
    @Test fun name_blank_isInvalid() = assertNotNull(Validators.name("   "))
    @Test fun name_present_isValid() = assertNull(Validators.name("Ada Lovelace"))

    // email
    @Test fun email_valid() = assertNull(Validators.email("ada@example.com"))
    @Test fun email_validWithSpacesAround() = assertNull(Validators.email("  ada@example.com  "))
    @Test fun email_missingDomain_isInvalid() = assertNotNull(Validators.email("ada@"))
    @Test fun email_missingAt_isInvalid() = assertNotNull(Validators.email("ada.example.com"))

    // password
    @Test fun password_tooShort() =
        assertEquals("Use at least 8 characters", Validators.password("abc1"))

    @Test fun password_withoutNumber() =
        assertEquals("Include at least one number", Validators.password("abcdefgh"))

    @Test fun password_valid() = assertNull(Validators.password("abcdefg1"))

    // confirm
    @Test fun confirm_mismatch() =
        assertEquals("Passwords do not match", Validators.confirm("abcdefg1", "abcdefg2"))

    @Test fun confirm_match() = assertNull(Validators.confirm("abcdefg1", "abcdefg1"))
}
