package com.example.sabi

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/** A hand-written fake: no delay, result controlled by the test. */
private class TestAuthRepository(var result: Result<Unit> = Result.success(Unit)) : AuthRepository {
    var signUpCalls = 0
    override suspend fun signUp(name: String, email: String, password: String): Result<Unit> {
        signUpCalls++
        return result
    }
    override suspend fun signIn(email: String, password: String): Result<Unit> = result
}

@OptIn(ExperimentalCoroutinesApi::class)
class SignUpViewModelTest {

    @Before fun setUp() = Dispatchers.setMain(UnconfinedTestDispatcher())
    @After fun tearDown() = Dispatchers.resetMain()

    private fun filledViewModel(repo: AuthRepository): SignUpViewModel =
        SignUpViewModel(repo).apply {
            onNameChange("Ada Lovelace")
            onEmailChange("ada@example.com")
            onPasswordChange("abcdefg1")
            onConfirmChange("abcdefg1")
        }

    @Test
    fun typing_updatesState() {
        val vm = SignUpViewModel(TestAuthRepository())
        vm.onNameChange("Ada")
        assertEquals("Ada", vm.state.value.name)
    }

    @Test
    fun canSubmit_falseWhenEmpty_trueWhenFilled() {
        val vm = SignUpViewModel(TestAuthRepository())
        assertFalse(vm.state.value.canSubmit)
        val filled = filledViewModel(TestAuthRepository())
        assertTrue(filled.state.value.canSubmit)
    }

    @Test
    fun submit_withInvalidEmail_showsErrorAndDoesNotCallRepository() = runTest {
        val repo = TestAuthRepository()
        val vm = filledViewModel(repo)
        vm.onEmailChange("not-an-email")

        vm.submit()
        advanceUntilIdle()

        assertNotNull(vm.state.value.emailError)
        assertEquals(0, repo.signUpCalls)
    }

    @Test
    fun submit_withMismatchedPasswords_showsConfirmError() = runTest {
        val repo = TestAuthRepository()
        val vm = filledViewModel(repo)
        vm.onConfirmChange("different1")

        vm.submit()
        advanceUntilIdle()

        assertEquals("Passwords do not match", vm.state.value.confirmError)
        assertEquals(0, repo.signUpCalls)
    }

    @Test
    fun submit_success_setsSignedUp() = runTest {
        val repo = TestAuthRepository(Result.success(Unit))
        val vm = filledViewModel(repo)

        vm.submit()
        advanceUntilIdle()

        assertTrue(vm.state.value.signedUp)
        assertFalse(vm.state.value.isLoading)
        assertNull(vm.state.value.error)
        assertEquals(1, repo.signUpCalls)
    }

    @Test
    fun submit_failure_showsServerError() = runTest {
        val repo = TestAuthRepository(Result.failure(IllegalStateException("That email is already in use")))
        val vm = filledViewModel(repo)

        vm.submit()
        advanceUntilIdle()

        assertFalse(vm.state.value.signedUp)
        assertFalse(vm.state.value.isLoading)
        assertEquals("That email is already in use", vm.state.value.error)
    }
}
