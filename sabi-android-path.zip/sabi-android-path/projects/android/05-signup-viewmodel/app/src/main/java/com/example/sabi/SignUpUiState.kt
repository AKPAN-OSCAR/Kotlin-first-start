package com.example.sabi

/** Everything the sign-up screen needs to draw itself. Immutable: change it with copy(). */
data class SignUpUiState(
    val name: String = "",
    val email: String = "",
    val password: String = "",
    val confirm: String = "",

    val nameError: String? = null,
    val emailError: String? = null,
    val passwordError: String? = null,
    val confirmError: String? = null,

    val isLoading: Boolean = false,
    /** A problem that came back from the repository (for example "Email already in use"). */
    val error: String? = null,
    /** True once the account exists. The UI reacts by navigating away. */
    val signedUp: Boolean = false,
) {
    /** Derived, not stored. */
    val canSubmit: Boolean
        get() = name.isNotBlank() && email.isNotBlank() &&
            password.isNotBlank() && confirm.isNotBlank() && !isLoading
}
