package com.example.sabi

import kotlinx.coroutines.delay

/** The data layer's promise. The ViewModel only knows this interface. */
interface AuthRepository {
    suspend fun signUp(name: String, email: String, password: String): Result<Unit>
    suspend fun signIn(email: String, password: String): Result<Unit>
}

/** A pretend backend for development. Replace with a Firebase implementation later. */
class FakeAuthRepository : AuthRepository {

    override suspend fun signUp(name: String, email: String, password: String): Result<Unit> {
        delay(800) // pretend network latency
        return if (email.trim().endsWith("@taken.com")) {
            Result.failure(IllegalStateException("That email is already in use"))
        } else {
            Result.success(Unit)
        }
    }

    override suspend fun signIn(email: String, password: String): Result<Unit> {
        delay(800)
        return Result.success(Unit)
    }
}
