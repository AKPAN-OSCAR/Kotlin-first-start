package com.example.sabi

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class SignUpViewModel(
    private val repository: AuthRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(SignUpUiState())
    val state: StateFlow<SignUpUiState> = _state.asStateFlow()

    // Events from the UI. Typing clears that field's error and any server error.
    fun onNameChange(value: String) = _state.update { it.copy(name = value, nameError = null, error = null) }
    fun onEmailChange(value: String) = _state.update { it.copy(email = value, emailError = null, error = null) }
    fun onPasswordChange(value: String) = _state.update { it.copy(password = value, passwordError = null, error = null) }
    fun onConfirmChange(value: String) = _state.update { it.copy(confirm = value, confirmError = null, error = null) }

    fun submit() {
        val s = _state.value
        if (s.isLoading) return

        val nameError = Validators.name(s.name)
        val emailError = Validators.email(s.email)
        val passwordError = Validators.password(s.password)
        val confirmError = Validators.confirm(s.password, s.confirm)

        if (listOf(nameError, emailError, passwordError, confirmError).any { it != null }) {
            _state.update {
                it.copy(
                    nameError = nameError,
                    emailError = emailError,
                    passwordError = passwordError,
                    confirmError = confirmError,
                )
            }
            return
        }

        viewModelScope.launch {
            _state.update { it.copy(isLoading = true, error = null) }
            repository.signUp(s.name.trim(), s.email.trim(), s.password)
                .onSuccess { _state.update { st -> st.copy(isLoading = false, signedUp = true) } }
                .onFailure { e ->
                    _state.update { st ->
                        st.copy(isLoading = false, error = e.message ?: "Something went wrong")
                    }
                }
        }
    }
}
