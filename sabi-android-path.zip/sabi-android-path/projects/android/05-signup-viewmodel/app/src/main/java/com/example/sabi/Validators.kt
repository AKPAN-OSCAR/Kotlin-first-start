package com.example.sabi

/**
 * Pure Kotlin: no Android imports, so it is trivial to unit-test.
 * Each function returns null when the value is valid, or a user-friendly error message.
 */
object Validators {

    private val emailRegex = Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")

    fun name(value: String): String? =
        if (value.isBlank()) "Enter your full name" else null

    fun email(value: String): String? =
        if (!emailRegex.matches(value.trim())) "Enter a valid email address" else null

    fun password(value: String): String? = when {
        value.length < 8 -> "Use at least 8 characters"
        value.none { it.isDigit() } -> "Include at least one number"
        else -> null
    }

    fun confirm(password: String, confirm: String): String? =
        if (password != confirm) "Passwords do not match" else null
}
