package com.example.sabi

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val CardGreen = Color(0xFFD2E8D4)
private val Ink = Color(0xFF073042)

@Composable
fun BusinessCard(
    name: String,
    title: String,
    phone: String,
    email: String,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CardGreen),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        // Top: avatar, name, title (takes the free space, centred)
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(
                imageVector = Icons.Filled.Person,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier
                    .size(120.dp)
                    .clip(CircleShape)
                    .background(Ink)
                    .padding(20.dp),
            )
            Spacer(Modifier.height(16.dp))
            Text(name, fontSize = 36.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text(title, fontSize = 18.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
        }

        // Bottom: contact rows
        Column(
            modifier = Modifier.padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            ContactRow(Icons.Filled.Phone, phone)
            ContactRow(Icons.Filled.Email, email)
        }
    }
}

@Composable
private fun ContactRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = Color(0xFF2E7D32))
        Spacer(Modifier.width(16.dp))
        Text(text, style = MaterialTheme.typography.bodyLarge, color = Ink)
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
private fun BusinessCardPreview() {
    MaterialTheme {
        BusinessCard("Ada Lovelace", "Android Developer", "+234 800 000 0000", "ada@example.com")
    }
}
