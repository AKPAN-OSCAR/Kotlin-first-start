# 01 Business card

**Lesson:** [Composables, layouts and modifiers](../../../curriculum/03-compose-ui/01-composables-layouts-modifiers.md)

## What you build
A single-screen digital business card using `Column`, `Row`, `Icon`, `Text` and modifiers.

## Instructions
1. Follow [`../SETUP.md`](../SETUP.md).
2. Read `BusinessCard.kt` and predict what the preview looks like before opening it.
3. Run it.

## Challenges
1. Replace the placeholder `Icon` with your photo (`Image(painterResource(...))` clipped to a circle).
2. Change colours to the SABI palette.
3. Add a "GitHub" row.
4. Make it look right in landscape (hint: scrolling or a `Row` layout).
5. Move all strings to `strings.xml`.
