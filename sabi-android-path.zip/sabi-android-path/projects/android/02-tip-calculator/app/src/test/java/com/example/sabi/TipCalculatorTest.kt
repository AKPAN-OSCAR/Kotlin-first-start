package com.example.sabi

import org.junit.Assert.assertEquals
import org.junit.Test

class TipCalculatorTest {

    @Test
    fun fifteenPercentOfHundred_isFifteen() {
        assertEquals(15.0, calculateTip(100.0, 15.0, roundUp = false), 0.001)
    }

    @Test
    fun roundUp_roundsToNextWholeNumber() {
        // 15% of 33 = 4.95 -> 5.0
        assertEquals(5.0, calculateTip(33.0, 15.0, roundUp = true), 0.001)
    }

    @Test
    fun zeroAmount_givesZeroTip() {
        assertEquals(0.0, calculateTip(0.0, 20.0, roundUp = false), 0.001)
    }
}
