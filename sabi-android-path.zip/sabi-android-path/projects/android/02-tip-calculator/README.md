# 02 Tip calculator

**Lesson:** [State and recomposition](../../../curriculum/03-compose-ui/03-state-recomposition.md)

## What you build
A calculator that takes a bill amount and a tip percentage and shows the tip, with a "round up" switch. You'll practise `remember`, `rememberSaveable`, state hoisting and a unit-tested pure function.

## Instructions
1. Follow [`../SETUP.md`](../SETUP.md).
2. Copy `TipCalculator.kt`, `MainActivity.kt` and the test from `src/test`.
3. Run it, rotate the emulator, and confirm the typed values survive (that's `rememberSaveable`).
4. Run the unit test (gutter arrow next to the test class).

## Challenges
1. Add a "split between N people" field and show the amount per person.
2. Show an error (`isError = true`) when the amount isn't a valid number.
3. Format the output in your local currency.
4. Move the calculation state into a ViewModel after lesson 04.
