# Using the Android projects

The projects here are **source only**: Kotlin files plus a README. They don't include Gradle wrappers or generated files, so you create a fresh project and drop the files in. This takes two minutes and teaches you how projects fit together.

## Steps (for every project)
1. In Android Studio: **New Project → Empty Activity**. Name it after the project folder, e.g. `TipCalculator`.
2. Delete the generated `MainActivity.kt` (and the generated `ui/theme` folder if the project says so).
3. Copy the project's `app/src/main/java/com/example/sabi/` files into your project's package folder. Your package name will differ, so **change the first line** (`package ...`) of each file, or use *Refactor → Move* in Studio.
4. Copy `app/src/test/...` files into `src/test/java/<your package>/` if present.
5. Add any dependencies listed in the project's README, then **Sync**.
6. Run.

## Dependencies by project
| Project | Extra dependencies beyond the Empty Activity defaults |
|---|---|
| 01 business card | none |
| 02 tip calculator | none (add JUnit for the test: Studio includes it by default) |
| 03 affirmations list | none |
| 04 SABI auth UI | `material-icons-extended`, `navigation-compose`, image assets |
| 05 signup ViewModel | `lifecycle-viewmodel-compose`, `lifecycle-runtime-compose`, `kotlinx-coroutines-test` (test) |
| 06 notes (Room) | `room-runtime`, `room-ktx`, `room-compiler` via KSP, the lifecycle libs above |

Use the Compose BOM Studio already added so you don't specify Compose versions.
Check current versions for non-Compose libraries on the [Jetpack release notes](https://developer.android.com/jetpack/androidx/versions) page.

## If the build fails
1. Read the **first** error in the Build output.
2. "Unresolved reference": missing import (Alt+Enter) or missing dependency.
3. "Cannot find symbol R.drawable.x": add that image to `res/drawable`.
4. Version conflicts: let Studio's suggestions or the BOM decide.
5. Still stuck after 20 minutes: ask for help with the exact error text.

## Note on this code
The author could not compile these files in a build environment. If something doesn't build, treat it as practice: fix it and, if you want, send a correction.
