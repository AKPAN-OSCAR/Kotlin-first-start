# 03 Affirmations list

**Lesson:** [Lists with LazyColumn](../../../curriculum/03-compose-ui/04-lists.md)

## What you build
A scrolling list of motivational study affirmations with a favourite toggle, using `LazyColumn`, `Card`, stable keys and `mutableStateListOf`.

## Instructions
1. Follow [`../SETUP.md`](../SETUP.md).
2. Copy the files and run.
3. Tap the heart on a few cards, scroll away and back, and note that state is kept (thanks to `key`).

## Challenges
1. Add a search `TextField` that filters the list as you type.
2. Show an empty state when the filter matches nothing.
3. Add images to each card (`painterResource` or Coil `AsyncImage`).
4. Add a "Favourites only" filter chip.
5. Move the list to a ViewModel (lesson 04).
