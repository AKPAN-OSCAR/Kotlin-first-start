package com.example.sabi

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

data class Affirmation(val id: Int, val text: String)

val sampleAffirmations = listOf(
    Affirmation(1, "I am capable of learning anything with practice."),
    Affirmation(2, "Small steps every day beat big steps once a month."),
    Affirmation(3, "Mistakes are how I get better."),
    Affirmation(4, "I show up even when I don't feel like it."),
    Affirmation(5, "Hard topics become easy when I stay patient."),
    Affirmation(6, "I ask questions because I want to understand."),
    Affirmation(7, "Rest is part of studying."),
    Affirmation(8, "My effort today builds my future."),
    Affirmation(9, "I can break big goals into small tasks."),
    Affirmation(10, "I celebrate progress, not perfection."),
)

@Composable
fun AffirmationsScreen(modifier: Modifier = Modifier) {
    // State lives here (the list owner); cards just report taps.
    val favourites = remember { mutableStateListOf<Int>() }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        items(sampleAffirmations, key = { it.id }) { affirmation ->
            AffirmationCard(
                affirmation = affirmation,
                isFavourite = affirmation.id in favourites,
                onToggleFavourite = {
                    if (affirmation.id in favourites) favourites.remove(affirmation.id)
                    else favourites.add(affirmation.id)
                },
            )
        }
    }
}

@Composable
fun AffirmationCard(
    affirmation: Affirmation,
    isFavourite: Boolean,
    onToggleFavourite: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = affirmation.text,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = onToggleFavourite) {
                Icon(
                    imageVector = if (isFavourite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = if (isFavourite) "Remove from favourites" else "Add to favourites",
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun AffirmationsPreview() {
    MaterialTheme { AffirmationsScreen() }
}
