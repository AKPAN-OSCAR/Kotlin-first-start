package com.example.sabi.auth

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.sabi.R

/* ---------- Design tokens ---------- */

private val SabiYellow = Color(0xFFFFEB1F)
private val SabiPurple = Color(0xFF7B16E8)
private val SabiPurpleLight = Color(0xFF9B4DFF)
private val SabiDeepPurple = Color(0xFF3D0C78)
private val SabiOrange = Color(0xFFFF9F1C)
private val SabiGreen = Color(0xFF1DC98A)
private val SabiCream = Color(0xFFFFF6B8)

// Swap these for Google Fonts (e.g. Fredoka / Baloo 2 for headings, Outfit for body)
// by adding the font files to res/font and building a FontFamily(Font(R.font.xxx)).
private val HeadingFont = FontFamily.Default
private val BodyFont = FontFamily.Default

/* ---------- Shared decorations ---------- */

@Composable
private fun TopDecorations() {
    Canvas(Modifier.fillMaxWidth().height(220.dp)) {
        // big purple circle (top-left)
        drawCircle(SabiPurple, radius = 90.dp.toPx(), center = Offset(-10.dp.toPx(), 40.dp.toPx()))
        // cream arc
        drawArc(
            color = SabiCream, startAngle = 200f, sweepAngle = 110f, useCenter = false,
            topLeft = Offset(10.dp.toPx(), (-70).dp.toPx()),
            size = androidx.compose.ui.geometry.Size(200.dp.toPx(), 200.dp.toPx()),
            style = Stroke(width = 6.dp.toPx())
        )
        // small orange dot
        drawCircle(SabiOrange, radius = 16.dp.toPx(), center = Offset(130.dp.toPx(), 125.dp.toPx()))
    }
}

@Composable
private fun BottomDecorations(modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxWidth().height(200.dp)) {
        // green ring (bottom-left)
        drawCircle(SabiCream, radius = 90.dp.toPx(), center = Offset(0f, size.height), style = Stroke(26.dp.toPx()))
        drawCircle(SabiGreen, radius = 62.dp.toPx(), center = Offset(0f, size.height), style = Stroke(26.dp.toPx()))
        // orange circle (bottom-right)
        drawCircle(SabiOrange, radius = 130.dp.toPx(), center = Offset(size.width, size.height + 40.dp.toPx()))
    }
}

/* ---------- Screen 1: Welcome ---------- */

@Composable
fun WelcomeScreen(
    onSignUpClick: () -> Unit,
    onSignInClick: () -> Unit,
) {
    Box(
        Modifier
            .fillMaxSize()
            .background(SabiYellow)
    ) {
        Box(Modifier.align(Alignment.TopStart)) { TopDecorations() }
        BottomDecorations(Modifier.align(Alignment.BottomCenter))

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(48.dp))

            // Logo (add sabi_logo to res/drawable)
            Image(
                painter = painterResource(R.drawable.sabi_logo),
                contentDescription = "SABI logo",
                modifier = Modifier.height(110.dp),
                contentScale = ContentScale.Fit
            )

            Spacer(Modifier.height(24.dp))

            Text(
                "WELCOME TO SABI.",
                fontFamily = HeadingFont, fontWeight = FontWeight.ExtraBold,
                fontSize = 30.sp, color = SabiDeepPurple, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "LEARN. CONNECT. GROW.",
                fontFamily = HeadingFont, fontWeight = FontWeight.Bold,
                fontSize = 14.sp, letterSpacing = 1.sp, color = SabiDeepPurple
            )

            Spacer(Modifier.height(24.dp))

            // Illustration (add welcome_books to res/drawable)
            Image(
                painter = painterResource(R.drawable.welcome_books),
                contentDescription = null,
                modifier = Modifier.height(210.dp),
                contentScale = ContentScale.Fit
            )

            Spacer(Modifier.height(24.dp))

            Text(
                "Want an adventure into the wonderland of excellent academic performance? You are in the right place.",
                fontFamily = BodyFont, fontSize = 16.sp, lineHeight = 24.sp,
                color = SabiDeepPurple, textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(32.dp))

            Button(
                onClick = onSignUpClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .shadow(12.dp, RoundedCornerShape(32.dp), ambientColor = SabiPurple, spotColor = SabiPurple),
                shape = RoundedCornerShape(32.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SabiPurple, contentColor = Color.White)
            ) {
                Text("SIGNUP", fontFamily = HeadingFont, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Spacer(Modifier.width(12.dp))
                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
            }

            Spacer(Modifier.height(20.dp))

            AlreadyHaveAccount(onSignInClick)

            Spacer(Modifier.height(120.dp))
        }
    }
}

@Composable
private fun AlreadyHaveAccount(onSignInClick: () -> Unit) {
    Text(
        text = buildAnnotatedString {
            append("Already have an account? ")
            withStyle(
                SpanStyle(
                    color = SabiPurple, fontWeight = FontWeight.Bold,
                    textDecoration = TextDecoration.Underline
                )
            ) { append("Sign in") }
        },
        fontFamily = BodyFont, fontSize = 15.sp, color = SabiDeepPurple,
        modifier = Modifier.clickable(onClick = onSignInClick)
    )
}

/* ---------- Screen 2: Create Account ---------- */

@Composable
fun SignUpScreen(
    onCreateAccount: (name: String, email: String, password: String) -> Unit,
    onSignInClick: () -> Unit,
) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var showConfirm by remember { mutableStateOf(false) }

    val passwordsMatch = password == confirm
    val canSubmit = name.isNotBlank() && email.contains("@") &&
            password.length >= 6 && passwordsMatch

    Box(
        Modifier
            .fillMaxSize()
            .background(SabiYellow)
    ) {
        Box(Modifier.align(Alignment.TopStart)) { TopDecorations() }
        BottomDecorations(Modifier.align(Alignment.BottomCenter))

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(28.dp))

            Image(
                painter = painterResource(R.drawable.sabi_logo),
                contentDescription = "SABI logo",
                modifier = Modifier.height(90.dp),
                contentScale = ContentScale.Fit
            )

            Spacer(Modifier.height(16.dp))

            Text(
                "CREATE YOUR ACCOUNT",
                fontFamily = HeadingFont, fontWeight = FontWeight.ExtraBold,
                fontSize = 26.sp, color = SabiDeepPurple, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Your journey to academic excellence starts here.",
                fontFamily = HeadingFont, fontWeight = FontWeight.Bold,
                fontSize = 14.sp, color = SabiDeepPurple, textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(24.dp))

            // "Glass" card
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color.White.copy(alpha = 0.30f))
                    .border28()
                    .padding(20.dp)
            ) {
                AuthField(
                    label = "Full Name", icon = Icons.Filled.Person,
                    value = name, onValueChange = { name = it },
                    placeholder = "Enter your full name"
                )
                Spacer(Modifier.height(16.dp))
                AuthField(
                    label = "Email Address", icon = Icons.Filled.Email,
                    value = email, onValueChange = { email = it },
                    placeholder = "Enter your email address",
                    keyboardType = KeyboardType.Email
                )
                Spacer(Modifier.height(16.dp))
                AuthField(
                    label = "Password", icon = Icons.Filled.Lock,
                    value = password, onValueChange = { password = it },
                    placeholder = "Create a password",
                    keyboardType = KeyboardType.Password,
                    isPassword = true, passwordVisible = showPassword,
                    onToggleVisibility = { showPassword = !showPassword }
                )
                Spacer(Modifier.height(16.dp))
                AuthField(
                    label = "Confirm Password", icon = Icons.Filled.Lock,
                    value = confirm, onValueChange = { confirm = it },
                    placeholder = "Confirm your password",
                    keyboardType = KeyboardType.Password,
                    isPassword = true, passwordVisible = showConfirm,
                    onToggleVisibility = { showConfirm = !showConfirm }
                )
                if (confirm.isNotEmpty() && !passwordsMatch) {
                    Text(
                        "Passwords do not match",
                        color = Color(0xFFD32F2F), fontSize = 12.sp,
                        modifier = Modifier.padding(start = 8.dp, top = 4.dp)
                    )
                }

                Spacer(Modifier.height(20.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .shadow(10.dp, RoundedCornerShape(28.dp), ambientColor = SabiPurple, spotColor = SabiPurple)
                        .clip(RoundedCornerShape(28.dp))
                        .background(
                            Brush.horizontalGradient(
                                if (canSubmit) listOf(SabiPurple, SabiPurpleLight)
                                else listOf(SabiPurple.copy(alpha = 0.6f), SabiPurpleLight.copy(alpha = 0.6f))
                            )
                        )
                        .clickable(enabled = canSubmit) { onCreateAccount(name.trim(), email.trim(), password) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "CREATE ACCOUNT",
                        fontFamily = HeadingFont, fontWeight = FontWeight.Bold,
                        fontSize = 18.sp, color = Color.White
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            AlreadyHaveAccount(onSignInClick)

            Spacer(Modifier.height(100.dp))
        }
    }
}

private fun Modifier.border28(): Modifier =
    this.then(
        Modifier.border(BorderStroke(1.dp, Color.White.copy(alpha = 0.6f)), RoundedCornerShape(28.dp))
    )

@Composable
private fun AuthField(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    isPassword: Boolean = false,
    passwordVisible: Boolean = false,
    onToggleVisibility: (() -> Unit)? = null,
) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 8.dp)) {
            Icon(icon, contentDescription = null, tint = SabiPurple, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Text(
                label, fontFamily = HeadingFont, fontWeight = FontWeight.Bold,
                fontSize = 15.sp, color = SabiDeepPurple
            )
        }
        Spacer(Modifier.height(8.dp))
        TextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text(placeholder, color = SabiDeepPurple.copy(alpha = 0.5f), fontFamily = BodyFont) },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
            visualTransformation = if (isPassword && !passwordVisible) PasswordVisualTransformation()
            else VisualTransformation.None,
            trailingIcon = if (isPassword && onToggleVisibility != null) {
                {
                    IconButton(onClick = onToggleVisibility) {
                        Icon(
                            if (passwordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                            contentDescription = if (passwordVisible) "Hide password" else "Show password",
                            tint = SabiPurple
                        )
                    }
                }
            } else null,
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.White.copy(alpha = 0.55f),
                unfocusedContainerColor = Color.White.copy(alpha = 0.45f),
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                cursorColor = SabiPurple,
                focusedTextColor = SabiDeepPurple,
                unfocusedTextColor = SabiDeepPurple
            )
        )
    }
}

/* ---------- Previews ---------- */

@Preview(showBackground = true, widthDp = 390, heightDp = 844)
@Composable
private fun WelcomePreview() = WelcomeScreen({}, {})

@Preview(showBackground = true, widthDp = 390, heightDp = 844)
@Composable
private fun SignUpPreview() = SignUpScreen({ _, _, _ -> }, {})
