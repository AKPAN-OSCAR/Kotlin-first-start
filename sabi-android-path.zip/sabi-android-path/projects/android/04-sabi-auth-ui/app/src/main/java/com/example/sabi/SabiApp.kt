package com.example.sabi

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.sabi.auth.SignUpScreen
import com.example.sabi.auth.WelcomeScreen

private object Routes {
    const val WELCOME = "welcome"
    const val SIGN_UP = "signup"
    const val SIGN_IN = "signin"
    const val HOME = "home"
}

@Composable
fun SabiApp() {
    val nav = rememberNavController()

    NavHost(navController = nav, startDestination = Routes.WELCOME) {

        composable(Routes.WELCOME) {
            WelcomeScreen(
                onSignUpClick = { nav.navigate(Routes.SIGN_UP) },
                onSignInClick = { nav.navigate(Routes.SIGN_IN) },
            )
        }

        composable(Routes.SIGN_UP) {
            SignUpScreen(
                onCreateAccount = { name, email, password ->
                    // TODO (lesson 06): call your AuthRepository here.
                    nav.navigate(Routes.HOME) {
                        // Remove the auth screens so Back on Home exits the app.
                        popUpTo(Routes.WELCOME) { inclusive = true }
                    }
                },
                onSignInClick = { nav.navigate(Routes.SIGN_IN) },
            )
        }

        composable(Routes.SIGN_IN) {
            // Placeholder. Challenge: build a real Sign in screen.
            PlaceholderScreen(
                title = "Sign in (build me!)",
                buttonLabel = "Pretend I signed in",
                onClick = {
                    nav.navigate(Routes.HOME) { popUpTo(Routes.WELCOME) { inclusive = true } }
                },
            )
        }

        composable(Routes.HOME) {
            PlaceholderScreen(title = "Home", buttonLabel = null, onClick = {})
        }
    }
}

@Composable
private fun PlaceholderScreen(title: String, buttonLabel: String?, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(title)
        if (buttonLabel != null) {
            Button(onClick = onClick, modifier = Modifier.padding(top = 16.dp)) { Text(buttonLabel) }
        }
    }
}
