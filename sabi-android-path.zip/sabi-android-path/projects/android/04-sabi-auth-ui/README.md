# 04 SABI auth UI

**Lessons:** [Forms and the SABI auth screens](../../../curriculum/03-compose-ui/05-forms-and-auth-ui.md) and [Navigation](../../../curriculum/03-compose-ui/06-navigation.md)

## What you build
The two SABI screens from the design (**Welcome** and **Create Account**), plus navigation between them and a placeholder Sign in and Home.

## Files
| File | Purpose |
|---|---|
| `auth/AuthScreens.kt` | `WelcomeScreen`, `SignUpScreen`, and the shared `AuthField` |
| `SabiApp.kt` | NavHost wiring Welcome, Sign up, Sign in, Home |
| `MainActivity.kt` | Hosts `SabiApp` |

## Dependencies
```kotlin
implementation("androidx.compose.material:material-icons-extended")   // VisibilityOff icon
implementation("androidx.navigation:navigation-compose:<current version>")
```
Use the Compose BOM Studio generated for Compose libraries.

## Assets you must add (`app/src/main/res/drawable/`)
| File name | What |
|---|---|
| `sabi_logo.png` | The SABI logo (books icon + wordmark) |
| `welcome_books.png` | The graduation-cap-on-books illustration |

Export them from your design tool (WebP or PNG, 2-3x resolution, transparent background). Until you have them, temporarily replace each `Image(painterResource(...))` with a `Box(Modifier.size(...).background(Color.White.copy(alpha = .3f)))` so the project builds.

The 3D cube, donut and pencil from the design are not in the code. Export them too and place them with `Image` in a `Box` using `Modifier.align(...)` and `offset`.

## Fonts
Both font families default to the system font. Download **Fredoka** (headings) and **Outfit** (body) from Google Fonts, put the `.ttf` files in `res/font/` (lowercase file names), and change `HeadingFont` / `BodyFont` at the top of `AuthScreens.kt`.

## Challenges
1. Build a **Sign in** screen (email + password) reusing `AuthField` (make it non-private or move it to its own file).
2. Move the colours into a `SabiTheme` (lesson 02).
3. Add the 3D decorations as images.
4. Make Back from Home close the app instead of returning to Sign up (see `popUpTo` in `SabiApp.kt`).
5. Next project: connect it to a ViewModel with validation, [`../05-signup-viewmodel`](../05-signup-viewmodel).
