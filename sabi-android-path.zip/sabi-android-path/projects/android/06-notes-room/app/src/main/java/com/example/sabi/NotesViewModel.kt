package com.example.sabi

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class NotesViewModel(private val dao: NoteDao) : ViewModel() {

    /** Hot StateFlow for the UI, fed by the database Flow. */
    val notes: StateFlow<List<Note>> = dao.observeAll()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList(),
        )

    fun add(title: String, body: String) {
        if (title.isBlank() && body.isBlank()) return
        viewModelScope.launch { dao.insert(Note(title = title.trim(), body = body.trim())) }
    }

    fun delete(note: Note) {
        viewModelScope.launch { dao.delete(note) }
    }
}
