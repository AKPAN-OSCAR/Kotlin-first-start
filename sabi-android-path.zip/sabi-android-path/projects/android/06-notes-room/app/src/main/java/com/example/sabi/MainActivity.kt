package com.example.sabi

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.room.Room

class MainActivity : ComponentActivity() {

    // One database instance for the whole app. (Later: provide it with Hilt.)
    private val db: AppDatabase by lazy {
        Room.databaseBuilder(applicationContext, AppDatabase::class.java, "sabi.db").build()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme {
                val viewModel: NotesViewModel = viewModel(
                    factory = viewModelFactory { initializer { NotesViewModel(db.noteDao()) } }
                )
                NotesRoute(viewModel, modifier = Modifier.safeDrawingPadding())
            }
        }
    }
}
