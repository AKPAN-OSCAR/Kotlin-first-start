package com.example.sabi

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

/** Route: owns the ViewModel connection. */
@Composable
fun NotesRoute(viewModel: NotesViewModel, modifier: Modifier = Modifier) {
    val notes by viewModel.notes.collectAsStateWithLifecycle()
    NotesScreen(
        notes = notes,
        onAdd = viewModel::add,
        onDelete = viewModel::delete,
        modifier = modifier,
    )
}

/** Screen: pure UI. */
@Composable
fun NotesScreen(
    notes: List<Note>,
    onAdd: (title: String, body: String) -> Unit,
    onDelete: (Note) -> Unit,
    modifier: Modifier = Modifier,
) {
    var title by rememberSaveable { mutableStateOf("") }
    var body by rememberSaveable { mutableStateOf("") }

    Column(modifier = modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("My notes", style = MaterialTheme.typography.headlineMedium)

        OutlinedTextField(
            value = title, onValueChange = { title = it },
            label = { Text("Title") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = body, onValueChange = { body = it },
            label = { Text("Note") }, modifier = Modifier.fillMaxWidth(),
        )
        Button(
            onClick = {
                onAdd(title, body)
                title = ""
                body = ""
            },
            enabled = title.isNotBlank() || body.isNotBlank(),
        ) { Text("Add note") }

        if (notes.isEmpty()) {
            Text("No notes yet. Add your first one above.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(notes, key = { it.id }) { note ->
                    NoteCard(note = note, onDelete = { onDelete(note) })
                }
            }
        }
    }
}

@Composable
private fun NoteCard(note: Note, onDelete: () -> Unit, modifier: Modifier = Modifier) {
    Card(modifier = modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                if (note.title.isNotBlank()) Text(note.title, style = MaterialTheme.typography.titleMedium)
                if (note.body.isNotBlank()) Text(note.body, style = MaterialTheme.typography.bodyMedium)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = "Delete note")
            }
        }
    }
}
