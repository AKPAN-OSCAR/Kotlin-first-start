# 06 Notes app with Room

**Lessons:** [Room database](../../../curriculum/05-data-and-networking/01-room.md), [ViewModel and UI state](../../../curriculum/04-architecture/01-viewmodel-uistate.md), [Coroutines and Flow](../../../curriculum/04-architecture/02-coroutines-flow.md)

## What you build
A notes app that saves to a local database. Add a note, see the list update automatically, delete a note, close the app and find your notes still there.

```
NotesScreen --> NotesViewModel --> NoteDao (Flow) --> Room / SQLite
```

## Dependencies
Room needs **KSP**. Add the KSP plugin to your project (`com.google.devtools.ksp`, version matching your Kotlin version, see the [KSP releases](https://github.com/google/ksp/releases)), then in `app/build.gradle.kts`:
```kotlin
plugins {
    id("com.google.devtools.ksp")
}
dependencies {
    implementation("androidx.room:room-runtime:<version>")
    implementation("androidx.room:room-ktx:<version>")
    ksp("androidx.room:room-compiler:<version>")

    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:<version>")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:<version>")
}
```
Find current versions on the [Room release page](https://developer.android.com/jetpack/androidx/releases/room). If the build complains about KSP and Kotlin versions not matching, align them.

## Files
| File | Role |
|---|---|
| `Note.kt` | Entity (table) |
| `NoteDao.kt` | Queries |
| `AppDatabase.kt` | Database class |
| `NotesViewModel.kt` | Holds list as `StateFlow`, adds/deletes |
| `NotesScreen.kt` | UI |
| `MainActivity.kt` | Builds the DB (one instance) and shows the screen |

## Challenges
1. Add **edit** (tap a note to change it, use `@Update` in the DAO).
2. Add a search box using a `LIKE` query.
3. Add a `pinned` column: bump the DB version to 2 and write a **Migration**.
4. Show an empty state ("No notes yet").
5. Move DB creation into Hilt (lesson 04-04).
6. Write a DAO test with an in-memory database (`Room.inMemoryDatabaseBuilder`, in `androidTest`).
