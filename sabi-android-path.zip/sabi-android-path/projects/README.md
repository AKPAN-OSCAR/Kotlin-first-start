# Projects

Practice that matches the lessons in `../curriculum`.

| Folder | What it is | Used in lessons |
|---|---|---|
| [`kotlin-exercises/`](kotlin-exercises/) | Runnable Kotlin files with `TODO()`s and a solutions folder | Kotlin foundations, coroutines |
| [`android/`](android/) | Compose app source for each stage | Compose, architecture, data |

Start with `kotlin-exercises`, then move through `android/01` to `android/06` in order. Setup instructions: [`android/SETUP.md`](android/SETUP.md).
