# Kotlin exercises

Each file has functions whose body is `TODO()`. Replace each `TODO()` with a working implementation, then run the file's `main`. You'll see `PASS`, `FAIL` or `TODO` for each check.

## How to run
- **Easiest:** copy a file into the [Kotlin Playground](https://play.kotlinlang.org/) (delete the `package` line first) and press Run. The playground supports coroutines too, so use it for exercise 05.
- **In IntelliJ IDEA (Community is free):** open this folder as a project, right-click a file, **Run**. For exercise 05 add the `org.jetbrains.kotlinx:kotlinx-coroutines-core` dependency.
- **Android Studio:** you can also run `main` from a plain Kotlin file inside any project.

## Files
| Exercise | Lesson |
|---|---|
| `01_basics.kt` | Variables, types and functions |
| `02_control_flow_nullability.kt` | Control flow and null safety |
| `03_classes_sealed.kt` | Classes, data classes, sealed types |
| `04_collections_lambdas.kt` | Collections and lambdas |
| `05_coroutines_flow.kt` | Coroutines and Flow |

Solutions live in `solutions/`. Try for at least 20 minutes before peeking.
