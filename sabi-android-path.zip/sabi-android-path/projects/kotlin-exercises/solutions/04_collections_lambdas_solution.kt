package sol04

// SOLUTION. Lesson: Collections and lambdas

data class Student(val name: String, val level: Int, val score: Int)

/** Scores that are >= 50, keeping the original order. */
fun passingScores(scores: List<Int>): List<Int> = scores.filter { it >= 50 }

/** Average of the scores, or 0.0 when the list is empty. */
fun averageOrZero(scores: List<Int>): Double =
    if (scores.isEmpty()) 0.0 else scores.average()

/** Names of students, sorted alphabetically. */
fun sortedNames(students: List<Student>): List<String> = students.map { it.name }.sorted()

/** Map of level -> list of student names in that level. Use groupBy then mapValues. */
fun namesByLevel(students: List<Student>): Map<Int, List<String>> =
    students.groupBy { it.level }.mapValues { (_, list) -> list.map { it.name } }

/** The student with the highest score, or null when the list is empty. */
fun topStudent(students: List<Student>): Student? = students.maxByOrNull { it.score }

/** Apply `f` to `x` twice. Example: applyTwice(3) { it * 2 } == 12 */
fun applyTwice(x: Int, f: (Int) -> Int): Int = f(f(x))

private fun <T> check(name: String, actual: () -> T, expected: T) {
    val result = try { actual() } catch (e: NotImplementedError) { println("TODO  $name"); return }
    println(if (result == expected) "PASS  $name" else "FAIL  $name (expected $expected, got $result)")
}

fun main() {
    val students = listOf(
        Student("Chidi", 1, 45),
        Student("Ada", 1, 82),
        Student("Bola", 2, 60),
    )
    check("passingScores", { passingScores(listOf(45, 60, 82, 10)) }, listOf(60, 82))
    check("averageOrZero", { averageOrZero(listOf(40, 60)) }, 50.0)
    check("averageOrZero empty", { averageOrZero(emptyList()) }, 0.0)
    check("sortedNames", { sortedNames(students) }, listOf("Ada", "Bola", "Chidi"))
    check("namesByLevel", { namesByLevel(students) }, mapOf(1 to listOf("Chidi", "Ada"), 2 to listOf("Bola")))
    check("topStudent", { topStudent(students)?.name }, "Ada")
    check("topStudent empty", { topStudent(emptyList()) }, null)
    check("applyTwice", { applyTwice(3) { it * 2 } }, 12)
}
