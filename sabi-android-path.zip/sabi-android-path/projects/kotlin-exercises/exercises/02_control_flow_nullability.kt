package ex02

// Lesson: Control flow and null safety

/** >=70 "A", >=60 "B", >=50 "C", otherwise "F". Use `when`. */
fun grade(score: Int): String = TODO()

/** 1..n as strings; multiples of 3 -> "Fizz", of 5 -> "Buzz", of both -> "FizzBuzz". */
fun fizzBuzz(n: Int): List<String> = TODO()

/**
 * Return the part of an email after '@', or null when the input is null
 * or has no '@'. Use ?. and ?: (no !!).
 */
fun emailDomain(email: String?): String? = TODO()

/** Return the length of the text, or 0 when it's null. One line using ?: */
fun safeLength(text: String?): Int = TODO()

/** Describe x: "text of length N" for Strings, "number N+1" for Ints (N is x), else "unknown". */
fun describe(x: Any): String = TODO()

private fun <T> check(name: String, actual: () -> T, expected: T) {
    val result = try { actual() } catch (e: NotImplementedError) { println("TODO  $name"); return }
    println(if (result == expected) "PASS  $name" else "FAIL  $name (expected $expected, got $result)")
}

fun main() {
    check("grade 82", { grade(82) }, "A")
    check("grade 65", { grade(65) }, "B")
    check("grade 50", { grade(50) }, "C")
    check("grade 10", { grade(10) }, "F")
    check("fizzBuzz", { fizzBuzz(15).takeLast(3) }, listOf("13", "14", "FizzBuzz"))
    check("fizzBuzz 3", { fizzBuzz(3) }, listOf("1", "2", "Fizz"))
    check("emailDomain ok", { emailDomain("ada@example.com") }, "example.com")
    check("emailDomain none", { emailDomain("ada") }, null)
    check("emailDomain null", { emailDomain(null) }, null)
    check("safeLength", { safeLength("abc") }, 3)
    check("safeLength null", { safeLength(null) }, 0)
    check("describe string", { describe("hey") }, "text of length 3")
    check("describe int", { describe(41) }, "number 42")
    check("describe other", { describe(2.5) }, "unknown")
}
