package ex05

// Lesson: Coroutines and Flow
// Needs kotlinx-coroutines-core. The Kotlin Playground (play.kotlinlang.org) has it built in.

import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.runBlocking

/** Provided: simulates a slow network call. */
suspend fun fetchGreeting(name: String): String {
    delay(100)
    return "Hello, $name!"
}

/**
 * Fetch greetings for all names **at the same time** (concurrently) and return them in order.
 * Hint: coroutineScope { names.map { async { ... } }.awaitAll() }
 */
suspend fun fetchAll(names: List<String>): List<String> = TODO()

/** A Flow that emits from, from-1, ..., 1 with a short delay between values. */
fun countdown(from: Int): Flow<Int> = TODO("use flow { ... emit(...) }")

/** Square every value of a flow using the map operator. */
fun squares(source: Flow<Int>): Flow<Int> = TODO()

/** Return the result of `block`, or `fallback` if it throws (use try/catch). */
suspend fun <T> orDefault(fallback: T, block: suspend () -> T): T = TODO()

private suspend fun <T> check(name: String, actual: suspend () -> T, expected: T) {
    val result = try { actual() } catch (e: NotImplementedError) { println("TODO  $name"); return }
    println(if (result == expected) "PASS  $name" else "FAIL  $name (expected $expected, got $result)")
}

fun main() = runBlocking {
    check("fetchAll", { fetchAll(listOf("Ada", "Bola")) }, listOf("Hello, Ada!", "Hello, Bola!"))
    check("countdown", { countdown(3).toList() }, listOf(3, 2, 1))
    check("squares", { squares(countdown(3)).toList() }, listOf(9, 4, 1))
    check("orDefault ok", { orDefault(0) { 5 } }, 5)
    check("orDefault fails", { orDefault(0) { error("boom") } }, 0)
}
