package ex01

// Lesson: Variables, types and functions
// Replace each TODO() with a real implementation, then run main().

/** "Ada", "Lovelace" -> "Ada Lovelace" */
fun fullName(first: String, last: String): String = TODO("use a string template")

/** Celsius to Fahrenheit: c * 9 / 5 + 32 */
fun celsiusToFahrenheit(c: Double): Double = TODO()

/** Return "<greeting>, <name>!" The greeting should default to "Hello". */
fun greet(name: String, greeting: String = "Hello"): String = TODO()

/** True when n is even. Write it as a single-expression function. */
fun isEven(n: Int): Boolean = TODO()

/** Return the area of a rectangle. */
fun area(width: Int, height: Int): Int = TODO()

private fun <T> check(name: String, actual: () -> T, expected: T) {
    val result = try { actual() } catch (e: NotImplementedError) { println("TODO  $name"); return }
    println(if (result == expected) "PASS  $name" else "FAIL  $name (expected $expected, got $result)")
}

fun main() {
    check("fullName", { fullName("Ada", "Lovelace") }, "Ada Lovelace")
    check("celsiusToFahrenheit 100", { celsiusToFahrenheit(100.0) }, 212.0)
    check("celsiusToFahrenheit 0", { celsiusToFahrenheit(0.0) }, 32.0)
    check("greet default", { greet("Ada") }, "Hello, Ada!")
    check("greet custom", { greet("Ada", "Hi") }, "Hi, Ada!")
    check("isEven 4", { isEven(4) }, true)
    check("isEven 7", { isEven(7) }, false)
    check("area", { area(3, 4) }, 12)
}
