package ex03

// Lesson: Classes, data classes and sealed types

data class Question(val text: String, val options: List<String>, val answerIndex: Int)

/** True when `choice` is the index of the correct option. */
fun isCorrect(q: Question, choice: Int): Boolean = TODO()

class Student(val name: String, var grade: Int) {
    /** Passing means grade >= 50. */
    fun isPassing(): Boolean = TODO()
}

sealed interface LoadState {
    data object Loading : LoadState
    data class Success(val items: List<String>) : LoadState
    data class Error(val message: String) : LoadState
}

/**
 * Loading -> "Loading..."
 * Success -> "Got N items"
 * Error   -> "Oops: <message>"
 * Use an exhaustive `when` with no `else`.
 */
fun render(state: LoadState): String = TODO()

/** Return a copy of the question with the text changed (use copy). */
fun withText(q: Question, newText: String): Question = TODO()

private fun <T> check(name: String, actual: () -> T, expected: T) {
    val result = try { actual() } catch (e: NotImplementedError) { println("TODO  $name"); return }
    println(if (result == expected) "PASS  $name" else "FAIL  $name (expected $expected, got $result)")
}

fun main() {
    val q = Question("2 + 2?", listOf("3", "4", "5"), 1)
    check("isCorrect yes", { isCorrect(q, 1) }, true)
    check("isCorrect no", { isCorrect(q, 0) }, false)
    check("Student passing", { Student("Ada", 72).isPassing() }, true)
    check("Student failing", { Student("Bola", 30).isPassing() }, false)
    check("render loading", { render(LoadState.Loading) }, "Loading...")
    check("render success", { render(LoadState.Success(listOf("a", "b"))) }, "Got 2 items")
    check("render error", { render(LoadState.Error("no network")) }, "Oops: no network")
    check("withText", { withText(q, "3 + 3?").text }, "3 + 3?")
    check("withText keeps options", { withText(q, "x").options }, q.options)
}
